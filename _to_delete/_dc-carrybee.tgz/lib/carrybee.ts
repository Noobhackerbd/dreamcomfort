// lib/carrybee.ts — CarryBee courier integration (mirrors the WooCommerce plugin).
// Auth is header-based: Client-ID / Client-Secret / Client-Context on every request.
// Endpoints (v2):
//   POST api/v2/orders                       → create consignment
//   GET  api/v2/orders/{consignment}/details → status
//   GET  api/v2/stores                       → merchant stores
//
// Env:
//   CARRYBEE_ENV = production | sandbox   (default production)
//   CARRYBEE_CLIENT_ID
//   CARRYBEE_CLIENT_SECRET
//   CARRYBEE_CLIENT_CONTEXT
//   CARRYBEE_STORE_ID   (default merchant store id used for new parcels)

const ENV = (process.env.CARRYBEE_ENV || "production").toLowerCase();
const BASE_URL =
  ENV === "sandbox" ? "https://sandbox.carrybee.com/" : "https://developers.carrybee.com/";

const CLIENT_ID = process.env.CARRYBEE_CLIENT_ID || "";
const CLIENT_SECRET = process.env.CARRYBEE_CLIENT_SECRET || "";
const CLIENT_CONTEXT = process.env.CARRYBEE_CLIENT_CONTEXT || "";
const STORE_ID = process.env.CARRYBEE_STORE_ID || "";

export function carrybeeConfigured(): boolean {
  return !!(CLIENT_ID && CLIENT_SECRET && CLIENT_CONTEXT);
}

function headers() {
  return {
    "Content-Type": "application/json",
    "Client-ID": CLIENT_ID,
    "Client-Secret": CLIENT_SECRET,
    "Client-Context": CLIENT_CONTEXT,
  };
}

/** Normalize a stored BD phone (8801XXXXXXXXX / 01XXXXXXXXX / +880…) to local 01XXXXXXXXX. */
export function toLocalBdPhone(raw: string): string {
  let d = (raw || "").replace(/\D/g, "");
  if (d.startsWith("00")) d = d.slice(2);
  if (d.startsWith("880")) d = "0" + d.slice(3); // 8801XXXXXXXXX → 01XXXXXXXXX
  else if (d.startsWith("1") && d.length === 10) d = "0" + d; // 1XXXXXXXXX → 01…
  return d;
}

export interface CarryBeeParcelInput {
  recipientName: string;
  recipientPhone: string;
  recipientAddress: string;
  collectableAmount: number; // COD amount (BDT)
  itemQuantity?: number;
  itemWeightGrams?: number; // default 500
  merchantOrderId?: string;
  specialInstruction?: string;
  productDescription?: string;
  storeId?: string; // overrides default
}

export interface CarryBeeResult {
  ok: boolean;
  consignmentId?: string;
  deliveryFee?: number;
  status?: string;
  error?: string;
  raw?: any;
}

function extractError(data: any, fallback: string): string {
  if (!data) return fallback;
  if (typeof data.message === "string" && data.message) return data.message;
  // v2 validation errors: { causes: { field: [msg] } } or { errors: {...} }
  const bag = data.causes || data.errors;
  if (bag && typeof bag === "object") {
    const msgs: string[] = [];
    for (const k of Object.keys(bag)) {
      const v = (bag as any)[k];
      if (Array.isArray(v)) msgs.push(...v.map(String));
      else if (typeof v === "string") msgs.push(v);
    }
    if (msgs.length) return msgs.join(" · ");
  }
  return fallback;
}

/** Create a CarryBee consignment (parcel) for an order. */
export async function createParcel(input: CarryBeeParcelInput): Promise<CarryBeeResult> {
  if (!carrybeeConfigured()) return { ok: false, error: "CarryBee কনফিগার করা হয়নি।" };
  const storeId = input.storeId || STORE_ID;
  if (!storeId) return { ok: false, error: "CARRYBEE_STORE_ID সেট করা নেই।" };

  const weight = Math.max(1, Math.round(input.itemWeightGrams || 500));
  const qty = Math.max(1, Math.floor(input.itemQuantity || 1));

  const body: Record<string, unknown> = {
    store_id: storeId,
    delivery_type: 1,
    product_type: 2,
    recipient_name: input.recipientName,
    recipient_phone: toLocalBdPhone(input.recipientPhone),
    recipient_address: input.recipientAddress,
    item_weight: weight, // grams
    item_quantity: qty,
    collectable_amount: Math.max(0, Math.round(input.collectableAmount)),
  };
  if (input.merchantOrderId) body.merchant_order_id = input.merchantOrderId;
  if (input.specialInstruction) body.special_instruction = input.specialInstruction;
  if (input.productDescription) body.product_description = input.productDescription;

  try {
    const res = await fetch(BASE_URL + "api/v2/orders", {
      method: "POST",
      headers: headers(),
      body: JSON.stringify(body),
      cache: "no-store",
    });
    const data = await res.json().catch(() => ({}));

    if (res.status !== 200 && res.status !== 201) {
      return { ok: false, error: extractError(data, "CarryBee অর্ডার তৈরি ব্যর্থ।"), raw: data };
    }
    if (data?.error === true) {
      return { ok: false, error: extractError(data, "CarryBee অর্ডার তৈরি ব্যর্থ।"), raw: data };
    }

    const order = data?.data?.order ?? data?.data ?? {};
    const consignmentId = String(order.consignment_id ?? "");
    if (!consignmentId) {
      return { ok: false, error: "CarryBee কনসাইনমেন্ট আইডি পাওয়া যায়নি।", raw: data };
    }
    return {
      ok: true,
      consignmentId,
      deliveryFee: order.delivery_fee != null ? Number(order.delivery_fee) : undefined,
      status: order.order_status ? String(order.order_status) : "Created",
      raw: data,
    };
  } catch (e: any) {
    return { ok: false, error: e?.message ?? "CarryBee নেটওয়ার্ক সমস্যা।" };
  }
}

/** Fetch current courier status for a consignment. */
export async function getParcelStatus(
  consignmentId: string
): Promise<{ ok: boolean; status?: string; error?: string; raw?: any }> {
  if (!carrybeeConfigured()) return { ok: false, error: "CarryBee কনফিগার করা হয়নি।" };
  try {
    const res = await fetch(
      BASE_URL + `api/v2/orders/${encodeURIComponent(consignmentId)}/details`,
      { headers: headers(), cache: "no-store" }
    );
    const data = await res.json().catch(() => ({}));
    if (res.status !== 200) return { ok: false, error: extractError(data, "স্ট্যাটাস আনতে ব্যর্থ।"), raw: data };
    const d = data?.data ?? {};
    const status = d.order_status ?? d.transfer_status ?? data?.status;
    return { ok: true, status: status ? String(status) : undefined, raw: data };
  } catch (e: any) {
    return { ok: false, error: e?.message ?? "নেটওয়ার্ক সমস্যা।" };
  }
}

/** List merchant stores (for finding your store_id). */
export async function listStores(): Promise<{ ok: boolean; stores?: any[]; error?: string }> {
  if (!carrybeeConfigured()) return { ok: false, error: "CarryBee কনফিগার করা হয়নি।" };
  try {
    const res = await fetch(BASE_URL + "api/v2/stores", { headers: headers(), cache: "no-store" });
    const data = await res.json().catch(() => ({}));
    if (res.status !== 200) return { ok: false, error: extractError(data, "স্টোর আনতে ব্যর্থ।") };
    const stores = data?.data?.stores ?? data?.data ?? data?.stores ?? [];
    return { ok: true, stores: Array.isArray(stores) ? stores : [] };
  } catch (e: any) {
    return { ok: false, error: e?.message ?? "নেটওয়ার্ক সমস্যা।" };
  }
}
