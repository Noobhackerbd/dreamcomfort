// app/page.tsx — premium single-product funnel homepage (CartFlows-style).
import { getServerSupabase } from "@/lib/supabase/server";
import { Product, Variant } from "@/lib/types";
import { getLandingConfig } from "@/lib/landing";
import { getShippingSettings } from "@/lib/settings";
import { taka } from "@/lib/format";
import { HeroSlider } from "@/components/funnel/HeroSlider";
import { OrderForm } from "@/components/funnel/OrderForm";
import { Reveal } from "@/components/Reveal";
import { ViewContentPixel } from "@/components/ViewContentPixel";

export const dynamic = "force-dynamic";

async function getHeroProduct(slug: string): Promise<Product | null> {
  const supabase = getServerSupabase();
  if (slug) {
    const { data } = await supabase.from("products").select("*").eq("slug", slug).eq("is_active", true).single();
    if (data) return data as Product;
  }
  const { data } = await supabase
    .from("products")
    .select("*")
    .eq("is_active", true)
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  return (data as Product) ?? null;
}

export default async function HomePage() {
  const landing = await getLandingConfig();
  const [product, shipping] = await Promise.all([
    getHeroProduct(landing.productSlug),
    getShippingSettings(),
  ]);

  if (!product) {
    return (
      <div className="text-center py-24">
        <h1 className="text-2xl font-bold">{landing.headline}</h1>
        <p className="mt-3 text-gray-500">
          ল্যান্ডিং পেজ দেখাতে অ্যাডমিন প্যানেলে একটি পণ্য যোগ করুন ও ল্যান্ডিং সেটিংসে সেটি নির্বাচন করুন।
        </p>
        <a href="/admin" className="mt-6 inline-block rounded-lg bg-brand text-white px-6 py-3">অ্যাডমিন প্যানেল</a>
      </div>
    );
  }

  const variants: Variant[] = product.variants ?? [];
  const name = product.name_bn || product.name_en;
  const heroImages = landing.heroImages.length ? landing.heroImages : product.images ?? [];

  // Display price = lowest available option.
  const prices = variants.length ? variants.map((v) => v.price) : [product.price];
  const displayPrice = Math.min(...prices);
  const displayCompare = variants.length
    ? Math.max(...variants.map((v) => v.compare_at_price ?? 0))
    : product.compare_at_price ?? 0;
  const hasDiscount = displayCompare > displayPrice;
  const off = hasDiscount ? Math.round((1 - displayPrice / displayCompare) * 100) : 0;

  return (
    <div className="-mt-8">
      <ViewContentPixel id={product.id} value={displayPrice} name={name} />

      {/* Announcement marquee */}
      <div className="overflow-hidden bg-brand text-white text-sm">
        <div className="flex whitespace-nowrap py-2 dc-marquee">
          {Array.from({ length: 2 }).map((_, k) => (
            <span key={k} className="flex shrink-0">
              {landing.badges.map((b, i) => (
                <span key={i} className="mx-6 inline-flex items-center gap-1">✓ {b}</span>
              ))}
            </span>
          ))}
        </div>
      </div>

      <div className="mx-auto max-w-6xl px-4">
        {/* HERO */}
        <section className="grid lg:grid-cols-2 gap-8 py-8 lg:py-12 items-start">
          <div className="dc-float lg:sticky lg:top-24">
            <HeroSlider images={heroImages} alt={name} />
          </div>

          <div>
            {landing.urgencyText && (
              <span className="inline-block rounded-full bg-red-50 text-red-600 text-sm px-3 py-1 mb-3">
                {landing.urgencyText}
              </span>
            )}
            <h1 className="text-3xl md:text-4xl font-extrabold leading-tight">{landing.headline}</h1>
            <p className="mt-3 text-gray-600 text-lg">{landing.subheadline}</p>

            <div className="mt-4 flex items-center gap-3">
              <span className="text-3xl font-extrabold text-brand">
                {variants.length ? "৳" : ""}{variants.length ? `${displayPrice} থেকে` : taka(displayPrice)}
              </span>
              {hasDiscount && (
                <>
                  <span className="text-gray-400 line-through text-lg">{taka(displayCompare)}</span>
                  <span className="rounded-full bg-red-100 text-red-600 text-sm px-2 py-0.5 font-semibold">{off}% ছাড়</span>
                </>
              )}
            </div>

            <div className="mt-4 flex flex-wrap gap-2">
              {landing.badges.map((b, i) => (
                <span key={i} className="rounded-full bg-brand/10 text-brand text-xs px-3 py-1">✓ {b}</span>
              ))}
            </div>

            <div className="mt-4 flex items-center gap-2 text-sm text-amber-500">
              ★★★★★ <span className="text-gray-500">{landing.statText}</span>
            </div>

            <div className="mt-6">
              <OrderForm
                productId={product.id}
                productName={name}
                basePrice={product.price}
                baseCompare={product.compare_at_price}
                baseImage={product.images?.[0]}
                variants={variants}
                shipping={{ inside: shipping.insideDhaka, outside: shipping.outsideDhaka }}
                ctaText={landing.ctaText}
              />
            </div>
          </div>
        </section>

        {/* BENEFITS */}
        <section className="py-10">
          <Reveal>
            <h2 className="text-2xl font-bold text-center mb-8">কেন এই পণ্যটি বেছে নেবেন?</h2>
          </Reveal>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {landing.benefits.map((b, i) => (
              <Reveal key={i} delay={i * 90}>
                <div className="rounded-2xl border bg-white p-5 text-center h-full hover:shadow-lg transition-shadow">
                  <div className="text-4xl">{b.icon}</div>
                  <h3 className="mt-3 font-bold">{b.title}</h3>
                  <p className="mt-1 text-sm text-gray-500">{b.text}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </section>

        {/* PRODUCT GALLERY STRIP */}
        {(product.images?.length ?? 0) > 0 && (
          <section className="py-6">
            <Reveal>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {(product.images ?? []).slice(0, 8).map((img, i) => (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img key={i} src={img} alt={name} className="aspect-square w-full object-cover rounded-2xl" />
                ))}
              </div>
            </Reveal>
          </section>
        )}

        {/* DESCRIPTION */}
        {(product.description_bn || product.description_en) && (
          <section className="py-8">
            <Reveal>
              <div className="rounded-2xl border bg-white p-6 max-w-3xl mx-auto">
                <h2 className="text-xl font-bold mb-3">পণ্যের বিবরণ</h2>
                <p className="text-gray-700 leading-relaxed whitespace-pre-line">
                  {product.description_bn || product.description_en}
                </p>
              </div>
            </Reveal>
          </section>
        )}

        {/* REVIEWS */}
        {landing.reviews.length > 0 && (
          <section className="py-10">
            <Reveal>
              <h2 className="text-2xl font-bold text-center mb-8">গ্রাহকদের মতামত</h2>
            </Reveal>
            <div className="grid gap-4 md:grid-cols-3">
              {landing.reviews.map((r, i) => (
                <Reveal key={i} delay={i * 90}>
                  <div className="rounded-2xl border bg-white p-5 h-full">
                    <div className="flex items-center gap-3">
                      {r.image ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={r.image} alt={r.name} className="h-10 w-10 rounded-full object-cover" />
                      ) : (
                        <span className="h-10 w-10 rounded-full bg-brand/10 text-brand flex items-center justify-center font-bold">
                          {r.name.charAt(0)}
                        </span>
                      )}
                      <div>
                        <p className="font-semibold text-sm">{r.name}</p>
                        <p className="text-amber-400 text-sm">{"★".repeat(r.stars)}{"☆".repeat(5 - r.stars)}</p>
                      </div>
                    </div>
                    <p className="mt-3 text-gray-700 text-sm">{r.text}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </section>
        )}

        {/* GUARANTEE */}
        <section className="py-10">
          <Reveal>
            <div className="rounded-3xl bg-gradient-to-br from-brand to-brand-dark text-white p-8 text-center">
              <div className="text-5xl">🛡️</div>
              <h2 className="mt-3 text-2xl font-bold">{landing.guaranteeTitle}</h2>
              <p className="mt-2 text-white/90 max-w-xl mx-auto">{landing.guaranteeText}</p>
              <a href="#order-form" className="mt-6 inline-block rounded-2xl bg-white text-brand px-8 py-3 font-bold hover:bg-white/90">
                {landing.ctaText}
              </a>
            </div>
          </Reveal>
        </section>
      </div>

      {/* Sticky mobile order bar */}
      <a
        href="#order-form"
        className="lg:hidden fixed bottom-3 inset-x-3 z-40 dc-cta rounded-2xl bg-brand text-white px-5 py-4 text-center font-bold shadow-2xl"
      >
        {landing.ctaText} · {taka(displayPrice)}
      </a>
      <div className="lg:hidden h-20" />
    </div>
  );
}
