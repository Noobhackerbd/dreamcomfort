"use server";

import { requireAdmin } from "@/lib/admin-auth";
import { saveSetting } from "@/lib/settings";
import type { LandingConfig } from "@/lib/landing";
import { revalidatePath } from "next/cache";

export async function saveLanding(config: LandingConfig) {
  await requireAdmin();
  await saveSetting("landing", config);
  revalidatePath("/");
  revalidatePath("/admin/landing");
  return { ok: true };
}
