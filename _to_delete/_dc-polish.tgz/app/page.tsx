// app/page.tsx — premium multi-product funnel homepage (Dream Comfort).
import { getServerSupabase } from "@/lib/supabase/server";
import { Product } from "@/lib/types";
import { getLandingConfig } from "@/lib/landing";
import { getShippingSettings } from "@/lib/settings";
import { STORE } from "@/lib/config";
import { taka } from "@/lib/format";
import { ProductFunnel } from "@/components/funnel/ProductFunnel";
import { Reveal } from "@/components/Reveal";
import { HeartsBg } from "@/components/funnel/HeartsBg";
import { SoundToggle } from "@/components/funnel/SoundToggle";
import { LandingBodyClass } from "@/components/funnel/LandingBodyClass";
import { StickyOrderButton } from "@/components/funnel/StickyOrderButton";
import { ProductShowcase } from "@/components/funnel/ProductShowcase";

export const dynamic = "force-dynamic";

async function getFeaturedProducts(slugs: string[], legacy: string): Promise<Product[]> {
  const supabase = getServerSupabase();
  const wanted = slugs.length ? slugs : legacy ? [legacy] : [];

  if (wanted.length) {
    const { data } = await supabase.from("products").select("*").in("slug", wanted).eq("is_active", true);
    const bySlug = new Map((data ?? []).map((p: any) => [p.slug, p as Product]));
    return wanted.map((s) => bySlug.get(s)).filter(Boolean) as Product[];
  }
  // No selection → feature all active products (newest first).
  const { data } = await supabase
    .from("products")
    .select("*")
    .eq("is_active", true)
    .order("created_at", { ascending: false })
    .limit(12);
  return (data as Product[]) ?? [];
}

export default async function HomePage() {
  const landing = await getLandingConfig();
  const [products, shipping] = await Promise.all([
    getFeaturedProducts(landing.productSlugs ?? [], landing.productSlug),
    getShippingSettings(),
  ]);

  const Logo = (
    <div className="flex flex-col items-center pt-8 pb-2">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={landing.logoUrl || "/logo.png"} alt={STORE.name} className="dc-float h-40 md:h-52 w-auto object-contain drop-shadow-sm" />
    </div>
  );

  if (products.length === 0) {
    return (
      <>
        <LandingBodyClass />
        {Logo}
        <div className="text-center py-16">
          <h1 className="font-display text-2xl font-bold">{landing.headline}</h1>
          <p className="mt-3 text-gray-500 max-w-md mx-auto">
            ল্যান্ডিং পেজ দেখাতে অ্যাডমিন প্যানেলে পণ্য যোগ করুন ও ল্যান্ডিং সেটিংসে সেগুলো নির্বাচন করুন।
          </p>
          <a href="/admin" className="mt-6 inline-block rounded-2xl bg-brand text-white px-6 py-3">অ্যাডমিন প্যানেল</a>
        </div>
      </>
    );
  }

  const minPrice = Math.min(...products.map((p) => Number(p.price)));

  return (
    <div className="-mt-8 relative">
      <LandingBodyClass />
      <HeartsBg />
      <SoundToggle />

      {/* soft animated background blobs */}
      <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden -z-10">
        <div className="dc-blob absolute -top-10 -left-10 h-72 w-72 rounded-full bg-brand-light/40" />
        <div className="dc-blob absolute top-40 -right-10 h-80 w-80 rounded-full bg-accent-light/40" style={{ animationDelay: "3s" }} />
      </div>

      {/* Logo header (no sticky bar) */}
      <div className="relative z-10">{Logo}</div>

      {/* Announcement marquee */}
      <div className="relative z-10 overflow-hidden rounded-full mx-auto max-w-3xl bg-gradient-to-r from-brand to-accent text-white text-sm shadow-soft">
        <div className="flex whitespace-nowrap py-2 dc-marquee">
          {Array.from({ length: 2 }).map((_, k) => (
            <span key={k} className="flex shrink-0">
              {landing.badges.map((b, i) => (
                <span key={i} className="mx-6 inline-flex items-center gap-1">✓ {b}</span>
              ))}
            </span>
          ))}
        </div>
      </div>

      <div className="relative z-10 mx-auto max-w-6xl px-1">
        {/* HERO + product picker + order form */}
        <ProductFunnel
          products={products}
          shipping={{ inside: shipping.insideDhaka, outside: shipping.outsideDhaka }}
          headline={landing.headline}
          subheadline={landing.subheadline}
          urgencyText={landing.urgencyText}
          statText={landing.statText}
          badges={landing.badges}
          ctaText={landing.ctaText}
        />

        {/* BENEFITS */}
        <section className="py-10">
          <Reveal>
            <h2 className="font-display text-2xl md:text-3xl font-bold text-center mb-8">
              কেন <span className="dc-gradient-text">Dream Comfort</span>?
            </h2>
          </Reveal>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {landing.benefits.map((b, i) => (
              <Reveal key={i} delay={i * 90}>
                <div className="rounded-[1.5rem] bg-white p-5 text-center h-full shadow-sm ring-1 ring-brand/5 hover:shadow-soft hover:-translate-y-1 transition-all">
                  <div className="text-4xl">{b.icon}</div>
                  <h3 className="mt-3 font-display font-bold">{b.title}</h3>
                  <p className="mt-1 text-sm text-gray-500">{b.text}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </section>

        {/* ALL FEATURED PRODUCTS showcase — cards select the product + jump to form */}
        <ProductShowcase products={products} />

        {/* REVIEWS */}
        {landing.reviews.length > 0 && (
          <section className="py-10">
            <Reveal>
              <h2 className="font-display text-2xl md:text-3xl font-bold text-center mb-8">গ্রাহকদের ভালোবাসা 💕</h2>
            </Reveal>
            <div className="grid gap-4 md:grid-cols-3">
              {landing.reviews.map((r, i) => (
                <Reveal key={i} delay={i * 90}>
                  <div className="rounded-[1.5rem] bg-white p-5 h-full shadow-sm ring-1 ring-accent/10">
                    <div className="flex items-center gap-3">
                      {r.image ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={r.image} alt={r.name} loading="lazy" decoding="async" className="h-11 w-11 rounded-full object-cover" />
                      ) : (
                        <span className="h-11 w-11 rounded-full bg-gradient-to-br from-brand-light to-accent-light text-white flex items-center justify-center font-bold">
                          {r.name.charAt(0)}
                        </span>
                      )}
                      <div>
                        <p className="font-semibold text-sm">{r.name}</p>
                        <p className="text-amber-400 text-sm">{"★".repeat(r.stars)}{"☆".repeat(5 - r.stars)}</p>
                      </div>
                    </div>
                    <p className="mt-3 text-gray-700 text-sm">{r.text}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </section>
        )}

        {/* GUARANTEE */}
        <section className="py-10">
          <Reveal>
            <div className="rounded-[2rem] bg-gradient-to-br from-brand to-accent text-white p-8 md:p-10 text-center shadow-soft">
              <div className="text-6xl dc-float">🛡️</div>
              <h2 className="mt-3 font-display text-2xl md:text-3xl font-bold">{landing.guaranteeTitle}</h2>
              <p className="mt-2 text-white/90 max-w-xl mx-auto">{landing.guaranteeText}</p>
              <a href="#order-form" className="mt-6 inline-block rounded-2xl bg-white text-accent-dark px-8 py-3 font-bold hover:scale-105 transition">
                {landing.ctaText} →
              </a>
            </div>
          </Reveal>
        </section>
      </div>

      {/* Sticky mobile order CTA — submits the order + hides when the form is on screen */}
      <StickyOrderButton label={`${landing.ctaText} · ${taka(minPrice)}`} />
      <div className="lg:hidden h-24" />
    </div>
  );
}
