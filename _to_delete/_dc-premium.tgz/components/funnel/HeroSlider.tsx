"use client";

import { useEffect, useState } from "react";

/** Auto-advancing image slideshow with crossfade, in a soft premium frame. */
export function HeroSlider({ images, alt }: { images: string[]; alt: string }) {
  const [i, setI] = useState(0);
  const has = images.length > 0;

  useEffect(() => {
    if (images.length < 2) return;
    const t = setInterval(() => setI((p) => (p + 1) % images.length), 3800);
    return () => clearInterval(t);
  }, [images.length]);

  return (
    <div className="relative">
      {/* soft glow behind */}
      <div className="absolute -inset-4 rounded-[2.5rem] bg-gradient-to-br from-brand-light/50 to-accent-light/50 blur-2xl" />
      <div className="relative aspect-square w-full overflow-hidden rounded-[2rem] bg-white shadow-soft ring-1 ring-white">
        {has ? (
          images.map((src, idx) => (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              key={src + idx}
              src={src}
              alt={alt}
              className="absolute inset-0 h-full w-full object-cover transition-opacity duration-[900ms]"
              style={{ opacity: idx === i ? 1 : 0 }}
            />
          ))
        ) : (
          <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-brand-soft to-accent-soft text-gray-400 font-display text-lg">
            {alt}
          </div>
        )}

        {images.length > 1 && (
          <>
            <button
              aria-label="prev"
              onClick={() => setI((p) => (p - 1 + images.length) % images.length)}
              className="absolute left-3 top-1/2 -translate-y-1/2 h-10 w-10 rounded-full bg-white/85 backdrop-blur text-gray-700 shadow hover:bg-white"
            >
              ‹
            </button>
            <button
              aria-label="next"
              onClick={() => setI((p) => (p + 1) % images.length)}
              className="absolute right-3 top-1/2 -translate-y-1/2 h-10 w-10 rounded-full bg-white/85 backdrop-blur text-gray-700 shadow hover:bg-white"
            >
              ›
            </button>
            <div className="absolute bottom-3 left-0 right-0 flex justify-center gap-1.5">
              {images.map((_, idx) => (
                <button
                  key={idx}
                  aria-label={`slide ${idx + 1}`}
                  onClick={() => setI(idx)}
                  className={"h-2 rounded-full transition-all " + (idx === i ? "w-7 bg-accent" : "w-2 bg-white/90")}
                />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
