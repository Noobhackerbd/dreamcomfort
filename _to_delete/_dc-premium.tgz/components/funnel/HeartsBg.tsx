"use client";

import { useMemo } from "react";

/** Soft blue/pink hearts drifting upward — matches the logo's little hearts. */
export function HeartsBg({ count = 14 }: { count?: number }) {
  const hearts = useMemo(
    () =>
      Array.from({ length: count }).map((_, i) => {
        // deterministic-ish spread by index (no Math.random needed at SSR)
        const left = (i * 37) % 100;
        const size = 10 + ((i * 13) % 22);
        const dur = 9 + ((i * 7) % 10);
        const delay = (i * 1.7) % 12;
        const pink = i % 2 === 0;
        return { left, size, dur, delay, pink, key: i };
      }),
    [count]
  );

  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 overflow-hidden z-0">
      {hearts.map((h) => (
        <span
          key={h.key}
          className="dc-heart"
          style={{
            left: `${h.left}%`,
            fontSize: `${h.size}px`,
            animationDuration: `${h.dur}s`,
            animationDelay: `${h.delay}s`,
            color: h.pink ? "#F0A0C0" : "#5FB4E4",
            opacity: 0.35,
          }}
        >
          ♥
        </span>
      ))}
    </div>
  );
}
