"use client";

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { placeOrder } from "@/app/checkout/actions";
import { fireEvent } from "@/components/track";
import { taka } from "@/lib/format";
import { playTick, playPop, playConfirm } from "@/lib/sound";
import type { Variant } from "@/lib/types";
import type { DeliveryArea } from "@/lib/config";

interface Props {
  productId: string;
  productName: string;
  basePrice: number;
  baseCompare?: number | null;
  baseImage?: string;
  variants: Variant[];
  shipping: { inside: number; outside: number };
  ctaText: string;
}

export function OrderForm({
  productId,
  productName,
  basePrice,
  baseCompare,
  variants,
  shipping,
  ctaText,
}: Props) {
  const router = useRouter();
  const [variantId, setVariantId] = useState<string>(variants[0]?.id ?? "");
  const [qty, setQty] = useState(1);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [city, setCity] = useState("");
  const [deliveryArea, setDeliveryArea] = useState<DeliveryArea>("inside");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const initiated = useRef(false);

  const selected = variants.find((v) => v.id === variantId);
  const unitPrice = selected ? selected.price : basePrice;
  const unitCompare = selected ? selected.compare_at_price ?? null : baseCompare ?? null;
  const subtotal = unitPrice * qty;
  const shippingFee = deliveryArea === "outside" ? shipping.outside : shipping.inside;
  const total = subtotal + shippingFee;
  const freeDelivery = shipping.inside === 0 && shipping.outside === 0;

  function markInitiated() {
    if (initiated.current) return;
    initiated.current = true;
    fireEvent("InitiateCheckout", {
      currency: "BDT",
      value: total,
      num_items: qty,
      content_ids: [productId],
      content_type: "product",
    });
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    playConfirm();
    const phoneDigits = phone.replace(/\D/g, "");
    if (!name.trim()) return setError("আপনার নাম লিখুন।");
    if (!/^01\d{9}$/.test(phoneDigits)) return setError("সঠিক মোবাইল নম্বর লিখুন (০১XXXXXXXXX)।");
    if (address.trim().length < 5) return setError("সম্পূর্ণ ঠিকানা লিখুন।");

    const fbclid =
      typeof window !== "undefined"
        ? new URLSearchParams(window.location.search).get("fbclid") ?? undefined
        : undefined;

    setSubmitting(true);
    const res = await placeOrder({
      name,
      phone,
      address,
      city,
      deliveryArea,
      items: [{ id: productId, qty, variantId: variantId || undefined }],
      fbclid,
    });
    setSubmitting(false);
    if (!res.ok) return setError(res.error ?? "অর্ডার ব্যর্থ হয়েছে।");
    router.push(`/order/${res.orderNumber}`);
  }

  const inputCls =
    "w-full rounded-2xl border border-brand/20 bg-white px-4 py-3 outline-none focus:border-brand focus:ring-4 focus:ring-brand/10 transition";

  return (
    <form
      id="order-form"
      onSubmit={onSubmit}
      onFocusCapture={markInitiated}
      className="rounded-[2rem] border border-white bg-white/80 backdrop-blur p-5 md:p-6 shadow-soft ring-1 ring-brand/10"
    >
      <div className="flex items-center gap-2 mb-4">
        <span className="inline-flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-brand to-accent text-white">🛒</span>
        <h3 className="font-display text-lg font-bold">অর্ডার করতে ফর্মটি পূরণ করুন</h3>
      </div>

      {variants.length > 0 && (
        <div className="mb-4">
          <label className="block text-sm font-medium mb-2">রং / মডেল বেছে নিন</label>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {variants.map((v) => {
              const on = v.id === variantId;
              return (
                <button
                  type="button"
                  key={v.id}
                  onClick={() => { setVariantId(v.id); playTick(); markInitiated(); }}
                  className={
                    "flex items-center gap-2 rounded-2xl border p-2 text-left transition " +
                    (on ? "border-accent ring-4 ring-accent/15 bg-accent-soft" : "border-brand/15 hover:border-brand/40")
                  }
                >
                  {v.image ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={v.image} alt={v.label} className="h-10 w-10 rounded-xl object-cover" />
                  ) : (
                    <span className="h-10 w-10 rounded-xl bg-gradient-to-br from-brand-light to-accent-light" />
                  )}
                  <span className="min-w-0">
                    <span className="block text-sm font-medium truncate">{v.label}</span>
                    <span className="block text-xs text-accent-dark font-bold">{taka(v.price)}</span>
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      <div className="mb-4 flex items-center justify-between">
        <label className="text-sm font-medium">পরিমাণ</label>
        <div className="flex items-center gap-3">
          <button type="button" onClick={() => { setQty((q) => Math.max(1, q - 1)); playPop(); }} className="h-9 w-9 rounded-xl border border-brand/20 text-lg hover:bg-brand-soft">−</button>
          <span className="w-8 text-center font-bold">{qty}</span>
          <button type="button" onClick={() => { setQty((q) => q + 1); playPop(); }} className="h-9 w-9 rounded-xl border border-brand/20 text-lg hover:bg-brand-soft">+</button>
        </div>
      </div>

      <div className="space-y-3">
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="আপনার নাম *" className={inputCls} />
        <input value={phone} onChange={(e) => setPhone(e.target.value)} inputMode="numeric" placeholder="মোবাইল নম্বর (০১XXXXXXXXX) *" className={inputCls} />
        <textarea value={address} onChange={(e) => setAddress(e.target.value)} rows={2} placeholder="সম্পূর্ণ ঠিকানা *" className={inputCls} />
        <input value={city} onChange={(e) => setCity(e.target.value)} placeholder="এলাকা / জেলা" className={inputCls} />
      </div>

      <div className="mt-4 grid grid-cols-2 gap-2">
        <button
          type="button"
          onClick={() => { setDeliveryArea("inside"); playTick(); }}
          className={"rounded-2xl border px-3 py-2.5 text-sm transition " + (deliveryArea === "inside" ? "border-brand bg-brand-soft text-brand-dark font-semibold" : "border-brand/15")}
        >
          ঢাকার ভিতরে {shipping.inside === 0 ? "· ফ্রি" : `· ${taka(shipping.inside)}`}
        </button>
        <button
          type="button"
          onClick={() => { setDeliveryArea("outside"); playTick(); }}
          className={"rounded-2xl border px-3 py-2.5 text-sm transition " + (deliveryArea === "outside" ? "border-brand bg-brand-soft text-brand-dark font-semibold" : "border-brand/15")}
        >
          ঢাকার বাইরে {shipping.outside === 0 ? "· ফ্রি" : `· ${taka(shipping.outside)}`}
        </button>
      </div>

      <div className="mt-4 rounded-2xl bg-cream-deep/60 p-4 text-sm space-y-1.5">
        <div className="flex justify-between">
          <span className="text-gray-500">{productName}{selected ? ` — ${selected.label}` : ""} × {qty}</span>
          <span>{taka(subtotal)}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-500">ডেলিভারি</span>
          <span>{shippingFee === 0 ? "ফ্রি 🎉" : taka(shippingFee)}</span>
        </div>
        <div className="flex justify-between border-t border-black/5 pt-2 text-base font-bold">
          <span>সর্বমোট</span>
          <span className="text-accent-dark">{taka(total)}</span>
        </div>
        {unitCompare && unitCompare > unitPrice && (
          <p className="text-xs text-green-600">🎁 আপনি সাশ্রয় করছেন {taka((unitCompare - unitPrice) * qty)}!</p>
        )}
      </div>

      {error && (
        <p className="mt-3 rounded-2xl bg-red-50 border border-red-200 text-red-700 px-4 py-2 text-sm">{error}</p>
      )}

      <button
        type="submit"
        disabled={submitting}
        className="dc-cta dc-pulse mt-4 w-full rounded-2xl bg-gradient-to-r from-accent to-accent-dark text-white px-6 py-4 text-lg font-bold disabled:opacity-60"
      >
        {submitting ? "অর্ডার হচ্ছে..." : `${ctaText} → ${taka(total)}`}
      </button>
      <p className="mt-2 text-center text-xs text-gray-400">
        💵 ক্যাশ অন ডেলিভারি {freeDelivery ? "· ফ্রি ডেলিভারি" : ""} · অর্ডারের পর কল করে কনফার্ম করা হবে
      </p>
    </form>
  );
}
