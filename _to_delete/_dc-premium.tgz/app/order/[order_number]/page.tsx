// Thank-you / order confirmation page (server component).
import { getServerSupabase } from "@/lib/supabase/server";
import { notFound } from "next/navigation";
import { taka } from "@/lib/format";
import { STORE } from "@/lib/config";
import { PurchasePixel } from "./PurchasePixel";

export const dynamic = "force-dynamic";

async function getOrder(orderNumber: string) {
  const supabase = getServerSupabase();
  const { data: order } = await supabase
    .from("orders")
    .select("*")
    .eq("order_number", orderNumber)
    .single();
  if (!order) return null;
  const { data: items } = await supabase
    .from("order_items")
    .select("*")
    .eq("order_id", order.id);
  return { order, items: items ?? [] };
}

export default async function OrderPage({
  params,
}: {
  params: { order_number: string };
}) {
  const data = await getOrder(params.order_number);
  if (!data) notFound();
  const { order, items } = data;

  return (
    <div className="max-w-2xl mx-auto text-center relative">
      {/* celebratory hearts burst */}
      <div aria-hidden className="pointer-events-none absolute inset-x-0 top-0 h-40 overflow-hidden">
        {Array.from({ length: 10 }).map((_, i) => (
          <span
            key={i}
            className="absolute text-2xl"
            style={{
              left: `${8 + i * 9}%`,
              color: i % 2 ? "#F0A0C0" : "#5FB4E4",
              animation: `dc-burst 1.4s ease-out ${i * 0.08}s both`,
            }}
          >
            ♥
          </span>
        ))}
      </div>

      <div className="text-6xl mb-3 dc-float">🎉</div>
      <h1 className="font-display text-2xl md:text-3xl font-bold">ধন্যবাদ! আপনার অর্ডার পেয়েছি 💕</h1>
      <p className="text-gray-500 mt-2">আমরা শীঘ্রই আপনাকে কল করে অর্ডারটি নিশ্চিত করব।</p>

      <div className="mt-6 rounded-[1.5rem] bg-white p-5 text-left shadow-soft ring-1 ring-brand/10">
        <div className="flex justify-between border-b border-black/5 pb-3 mb-3">
          <span className="text-gray-500">অর্ডার নম্বর</span>
          <span className="font-bold text-accent-dark">{order.order_number}</span>
        </div>

        <div className="space-y-2">
          {items.map((it: any) => (
            <div key={it.id} className="flex justify-between text-sm">
              <span className="truncate pr-2">{it.product_name} × {it.quantity}</span>
              <span>{taka(Number(it.line_total))}</span>
            </div>
          ))}
        </div>

        <div className="mt-3 border-t border-black/5 pt-3 space-y-1 text-sm">
          <div className="flex justify-between">
            <span>ডেলিভারি চার্জ</span>
            <span>{Number(order.shipping_fee) === 0 ? "ফ্রি 🎉" : taka(Number(order.shipping_fee))}</span>
          </div>
          <div className="flex justify-between font-bold text-lg">
            <span>সর্বমোট</span>
            <span className="text-accent-dark">{taka(Number(order.total))}</span>
          </div>
        </div>

        <div className="mt-4 border-t border-black/5 pt-3 text-sm text-gray-600 space-y-0.5">
          <p><b>নাম:</b> {order.customer_name}</p>
          <p><b>মোবাইল:</b> {order.customer_phone}</p>
          <p><b>ঠিকানা:</b> {order.address_line}</p>
          <p><b>পেমেন্ট:</b> ক্যাশ অন ডেলিভারি</p>
        </div>
      </div>

      <div className="mt-6 flex flex-wrap gap-3 justify-center">
        <a href="/" className="rounded-2xl bg-brand text-white px-6 py-3 font-medium hover:bg-brand-dark">
          হোমে ফিরে যান
        </a>
        <a href={`tel:${STORE.phone}`} className="rounded-2xl border border-brand/30 text-brand-dark px-6 py-3 font-medium hover:bg-brand-soft">
          📞 {STORE.phone}
        </a>
      </div>

      <PurchasePixel
        eventId={order.event_id ?? null}
        value={Number(order.total)}
        contentIds={items.map((it: any) => it.product_id).filter(Boolean)}
      />
    </div>
  );
}
