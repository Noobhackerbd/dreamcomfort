// app/page.tsx — premium single-product funnel homepage (matches the Dream Comfort logo vibe).
import { getServerSupabase } from "@/lib/supabase/server";
import { Product, Variant } from "@/lib/types";
import { getLandingConfig } from "@/lib/landing";
import { getShippingSettings } from "@/lib/settings";
import { STORE } from "@/lib/config";
import { taka } from "@/lib/format";
import { HeroSlider } from "@/components/funnel/HeroSlider";
import { OrderForm } from "@/components/funnel/OrderForm";
import { Reveal } from "@/components/Reveal";
import { ViewContentPixel } from "@/components/ViewContentPixel";
import { HeartsBg } from "@/components/funnel/HeartsBg";
import { SoundToggle } from "@/components/funnel/SoundToggle";
import { LandingBodyClass } from "@/components/funnel/LandingBodyClass";

export const dynamic = "force-dynamic";

async function getHeroProduct(slug: string): Promise<Product | null> {
  const supabase = getServerSupabase();
  if (slug) {
    const { data } = await supabase.from("products").select("*").eq("slug", slug).eq("is_active", true).single();
    if (data) return data as Product;
  }
  const { data } = await supabase
    .from("products")
    .select("*")
    .eq("is_active", true)
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  return (data as Product) ?? null;
}

export default async function HomePage() {
  const landing = await getLandingConfig();
  const [product, shipping] = await Promise.all([
    getHeroProduct(landing.productSlug),
    getShippingSettings(),
  ]);

  const Logo = (
    <div className="flex flex-col items-center pt-8 pb-2">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={landing.logoUrl || "/logo.png"} alt={STORE.name} className="dc-float h-40 md:h-52 w-auto object-contain drop-shadow-sm" />
    </div>
  );

  if (!product) {
    return (
      <>
        <LandingBodyClass />
        {Logo}
        <div className="text-center py-16">
          <h1 className="font-display text-2xl font-bold">{landing.headline}</h1>
          <p className="mt-3 text-gray-500 max-w-md mx-auto">
            ল্যান্ডিং পেজ দেখাতে অ্যাডমিন প্যানেলে একটি পণ্য যোগ করুন ও ল্যান্ডিং সেটিংসে সেটি নির্বাচন করুন।
          </p>
          <a href="/admin" className="mt-6 inline-block rounded-2xl bg-brand text-white px-6 py-3">অ্যাডমিন প্যানেল</a>
        </div>
      </>
    );
  }

  const variants: Variant[] = product.variants ?? [];
  const name = product.name_bn || product.name_en;
  const heroImages = landing.heroImages.length ? landing.heroImages : product.images ?? [];

  const prices = variants.length ? variants.map((v) => v.price) : [product.price];
  const displayPrice = Math.min(...prices);
  const displayCompare = variants.length
    ? Math.max(...variants.map((v) => v.compare_at_price ?? 0))
    : product.compare_at_price ?? 0;
  const hasDiscount = displayCompare > displayPrice;
  const off = hasDiscount ? Math.round((1 - displayPrice / displayCompare) * 100) : 0;

  return (
    <div className="-mt-8 relative">
      <LandingBodyClass />
      <HeartsBg />
      <SoundToggle />
      <ViewContentPixel id={product.id} value={displayPrice} name={name} />

      {/* soft animated background blobs */}
      <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden -z-10">
        <div className="dc-blob absolute -top-10 -left-10 h-72 w-72 rounded-full bg-brand-light/40" />
        <div className="dc-blob absolute top-40 -right-10 h-80 w-80 rounded-full bg-accent-light/40" style={{ animationDelay: "3s" }} />
      </div>

      {/* Logo header (no sticky bar) */}
      <div className="relative z-10">{Logo}</div>

      {/* Announcement marquee */}
      <div className="relative z-10 overflow-hidden rounded-full mx-auto max-w-3xl bg-gradient-to-r from-brand to-accent text-white text-sm shadow-soft">
        <div className="flex whitespace-nowrap py-2 dc-marquee">
          {Array.from({ length: 2 }).map((_, k) => (
            <span key={k} className="flex shrink-0">
              {landing.badges.map((b, i) => (
                <span key={i} className="mx-6 inline-flex items-center gap-1">✓ {b}</span>
              ))}
            </span>
          ))}
        </div>
      </div>

      <div className="relative z-10 mx-auto max-w-6xl px-1">
        {/* HERO */}
        <section className="grid lg:grid-cols-2 gap-8 py-8 lg:py-12 items-start">
          <div className="lg:sticky lg:top-8">
            <HeroSlider images={heroImages} alt={name} />
          </div>

          <div>
            {landing.urgencyText && (
              <span className="inline-block rounded-full bg-accent-soft text-accent-dark text-sm px-3 py-1 mb-3 dc-wiggle">
                {landing.urgencyText}
              </span>
            )}
            <h1 className="font-display text-3xl md:text-4xl font-bold leading-tight">
              {landing.headline}
            </h1>
            <p className="mt-3 text-gray-600 text-lg">{landing.subheadline}</p>

            <div className="mt-4 flex items-end gap-3">
              <span className="font-display text-4xl font-bold text-accent-dark">
                {variants.length ? `৳${displayPrice} থেকে` : taka(displayPrice)}
              </span>
              {hasDiscount && (
                <>
                  <span className="text-gray-400 line-through text-lg mb-1">{taka(displayCompare)}</span>
                  <span className="mb-1 rounded-full bg-accent text-white text-sm px-2 py-0.5 font-bold">{off}% ছাড়</span>
                </>
              )}
            </div>

            <div className="mt-4 flex flex-wrap gap-2">
              {landing.badges.map((b, i) => (
                <span key={i} className="rounded-full bg-white shadow-sm text-brand-dark text-xs px-3 py-1.5 ring-1 ring-brand/10">✓ {b}</span>
              ))}
            </div>

            <div className="mt-4 flex items-center gap-2 text-sm">
              <span className="text-amber-400 text-lg">★★★★★</span>
              <span className="text-gray-500">{landing.statText}</span>
            </div>

            <div className="mt-6">
              <OrderForm
                productId={product.id}
                productName={name}
                basePrice={product.price}
                baseCompare={product.compare_at_price}
                baseImage={product.images?.[0]}
                variants={variants}
                shipping={{ inside: shipping.insideDhaka, outside: shipping.outsideDhaka }}
                ctaText={landing.ctaText}
              />
            </div>
          </div>
        </section>

        {/* BENEFITS */}
        <section className="py-10">
          <Reveal>
            <h2 className="font-display text-2xl md:text-3xl font-bold text-center mb-8">
              কেন <span className="dc-gradient-text">Dream Comfort</span>?
            </h2>
          </Reveal>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {landing.benefits.map((b, i) => (
              <Reveal key={i} delay={i * 90}>
                <div className="rounded-[1.5rem] bg-white p-5 text-center h-full shadow-sm ring-1 ring-brand/5 hover:shadow-soft hover:-translate-y-1 transition-all">
                  <div className="text-4xl">{b.icon}</div>
                  <h3 className="mt-3 font-display font-bold">{b.title}</h3>
                  <p className="mt-1 text-sm text-gray-500">{b.text}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </section>

        {/* PRODUCT GALLERY */}
        {(product.images?.length ?? 0) > 0 && (
          <section className="py-6">
            <Reveal>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {(product.images ?? []).slice(0, 8).map((img, i) => (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img key={i} src={img} alt={name} className="aspect-square w-full object-cover rounded-[1.25rem] shadow-sm hover:scale-[1.03] transition" />
                ))}
              </div>
            </Reveal>
          </section>
        )}

        {/* DESCRIPTION */}
        {(product.description_bn || product.description_en) && (
          <section className="py-8">
            <Reveal>
              <div className="rounded-[1.75rem] bg-white p-6 max-w-3xl mx-auto shadow-sm ring-1 ring-brand/5">
                <h2 className="font-display text-xl font-bold mb-3">পণ্যের বিবরণ</h2>
                <p className="text-gray-700 leading-relaxed whitespace-pre-line">
                  {product.description_bn || product.description_en}
                </p>
              </div>
            </Reveal>
          </section>
        )}

        {/* REVIEWS */}
        {landing.reviews.length > 0 && (
          <section className="py-10">
            <Reveal>
              <h2 className="font-display text-2xl md:text-3xl font-bold text-center mb-8">গ্রাহকদের ভালোবাসা 💕</h2>
            </Reveal>
            <div className="grid gap-4 md:grid-cols-3">
              {landing.reviews.map((r, i) => (
                <Reveal key={i} delay={i * 90}>
                  <div className="rounded-[1.5rem] bg-white p-5 h-full shadow-sm ring-1 ring-accent/10">
                    <div className="flex items-center gap-3">
                      {r.image ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={r.image} alt={r.name} className="h-11 w-11 rounded-full object-cover" />
                      ) : (
                        <span className="h-11 w-11 rounded-full bg-gradient-to-br from-brand-light to-accent-light text-white flex items-center justify-center font-bold">
                          {r.name.charAt(0)}
                        </span>
                      )}
                      <div>
                        <p className="font-semibold text-sm">{r.name}</p>
                        <p className="text-amber-400 text-sm">{"★".repeat(r.stars)}{"☆".repeat(5 - r.stars)}</p>
                      </div>
                    </div>
                    <p className="mt-3 text-gray-700 text-sm">{r.text}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </section>
        )}

        {/* GUARANTEE */}
        <section className="py-10">
          <Reveal>
            <div className="rounded-[2rem] bg-gradient-to-br from-brand to-accent text-white p-8 md:p-10 text-center shadow-soft">
              <div className="text-6xl dc-float">🛡️</div>
              <h2 className="mt-3 font-display text-2xl md:text-3xl font-bold">{landing.guaranteeTitle}</h2>
              <p className="mt-2 text-white/90 max-w-xl mx-auto">{landing.guaranteeText}</p>
              <a href="#order-form" className="mt-6 inline-block rounded-2xl bg-white text-accent-dark px-8 py-3 font-bold hover:scale-105 transition">
                {landing.ctaText} →
              </a>
            </div>
          </Reveal>
        </section>
      </div>

      {/* Sticky mobile order CTA */}
      <a
        href="#order-form"
        className="lg:hidden fixed bottom-3 inset-x-3 z-40 dc-cta rounded-2xl bg-gradient-to-r from-accent to-accent-dark text-white px-5 py-4 text-center font-bold shadow-2xl"
      >
        {landing.ctaText} · {taka(displayPrice)}
      </a>
      <div className="lg:hidden h-20" />
    </div>
  );
}
