// lib/ai.ts — Anthropic vision helper used by the "AI order from screenshot" feature.
// Reads a Messenger/WhatsApp order screenshot and extracts the customer's
// name / phone / address so the admin only has to pick the product + amount.

import { getAiSettings } from "@/lib/settings";

export async function aiConfigured(): Promise<boolean> {
  const s = await getAiSettings();
  return !!s.apiKey;
}

export interface ExtractedOrder {
  name: string;
  phone: string;
  address: string;
  area: string;
  city: string;
  note: string;
}

const EXTRACT_PROMPT = `You are helping a Bangladeshi e-commerce shop enter a customer order.
The image is a screenshot of a Messenger/WhatsApp chat or an order note, often written in Bengali or "Banglish" (Bengali in English letters).

Extract ONLY the customer's delivery details and return a single JSON object with EXACTLY these keys:
{"name": "", "phone": "", "address": "", "area": "", "city": "", "note": ""}

Rules:
- phone: the customer's Bangladeshi mobile number, digits only, in local format like 01712345678. If multiple, pick the customer's (not the shop's).
- address: the full street/house/road delivery address.
- area / city: the thana/area and district/city if identifiable (e.g. Mirpur, Dhaka). Leave empty if unclear.
- note: any special instruction from the customer.
- Use an empty string "" for anything not present. Do NOT guess a phone or name if it is not there.
- Return ONLY the JSON object, no explanation, no markdown.`;

/** Send the screenshot to Anthropic and parse the extracted order JSON. */
export async function extractOrderFromImage(
  base64: string,
  mediaType: string
): Promise<{ ok: boolean; data?: ExtractedOrder; error?: string }> {
  const s = await getAiSettings();
  if (!s.apiKey) return { ok: false, error: "AI API key সেট করা নেই (Settings এ যোগ করুন)।" };

  const allowed = ["image/jpeg", "image/png", "image/webp", "image/gif"];
  const mt = allowed.includes(mediaType) ? mediaType : "image/jpeg";

  try {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": s.apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: s.model || "claude-3-5-sonnet-20241022",
        max_tokens: 600,
        messages: [
          {
            role: "user",
            content: [
              { type: "image", source: { type: "base64", media_type: mt, data: base64 } },
              { type: "text", text: EXTRACT_PROMPT },
            ],
          },
        ],
      }),
    });

    const data = await res.json().catch(() => null);
    if (!res.ok) {
      return { ok: false, error: data?.error?.message || `AI অনুরোধ ব্যর্থ (${res.status})।` };
    }

    const text: string = data?.content?.[0]?.text ?? "";
    const match = text.match(/\{[\s\S]*\}/);
    if (!match) return { ok: false, error: "স্ক্রিনশট থেকে তথ্য পড়া যায়নি।" };

    const p = JSON.parse(match[0]);
    return {
      ok: true,
      data: {
        name: String(p.name ?? "").trim(),
        phone: String(p.phone ?? "").replace(/\D/g, ""),
        address: String(p.address ?? "").trim(),
        area: String(p.area ?? "").trim(),
        city: String(p.city ?? "").trim(),
        note: String(p.note ?? "").trim(),
      },
    };
  } catch (e: any) {
    return { ok: false, error: e?.message ?? "AI নেটওয়ার্ক সমস্যা।" };
  }
}
