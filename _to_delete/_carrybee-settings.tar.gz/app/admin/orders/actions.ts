"use server";

import { getServerSupabase } from "@/lib/supabase/server";
import { requireAdmin } from "@/lib/admin-auth";
import { getSmsTemplates } from "@/lib/settings";
import { sendSmsAsync } from "@/lib/sms";
import { fillTemplate, STATUS_SMS_MAP } from "@/lib/sms/templates";
import { createParcel, getParcelStatus, carrybeeConfigured, listCities, listZones, listAreas } from "@/lib/carrybee";
import { revalidatePath } from "next/cache";

const STATUSES = [
  "pending",
  "confirmed",
  "processing",
  "shipped",
  "delivered",
  "cancelled",
  "returned",
];

export async function updateOrderStatus(orderId: string, status: string) {
  await requireAdmin();
  if (!STATUSES.includes(status)) return { ok: false, error: "invalid status" };
  const supabase = getServerSupabase();
  const { error } = await supabase.from("orders").update({ status }).eq("id", orderId);
  if (error) return { ok: false, error: error.message };

  // Send a status SMS if this status maps to a template (confirmed/shipped/delivered).
  const templateKey = STATUS_SMS_MAP[status];
  if (templateKey) {
    try {
      const { data: order } = await supabase
        .from("orders")
        .select("customer_name, customer_phone, order_number, tracking_id")
        .eq("id", orderId)
        .single();
      if (order) {
        const templates = await getSmsTemplates();
        const msg = fillTemplate(templates[templateKey], {
          name: order.customer_name,
          order: order.order_number,
          tracking: order.tracking_id ?? "",
        });
        void sendSmsAsync({ phone: order.customer_phone, message: msg, orderId });
      }
    } catch {
      /* never block a status change on SMS */
    }
  }

  revalidatePath("/admin/orders");
  revalidatePath(`/admin/orders/${orderId}`);
  return { ok: true };
}

export async function updateOrderCourier(
  orderId: string,
  courier: string,
  trackingId: string
) {
  await requireAdmin();
  const supabase = getServerSupabase();
  const { error } = await supabase
    .from("orders")
    .update({ courier: courier.trim() || null, tracking_id: trackingId.trim() || null })
    .eq("id", orderId);
  if (error) return { ok: false, error: error.message };
  revalidatePath(`/admin/orders/${orderId}`);
  return { ok: true };
}

/** Send an order to CarryBee courier — creates a consignment and stores it on the order. */
export async function sendToCarryBee(orderId: string) {
  await requireAdmin();
  if (!(await carrybeeConfigured())) {
    return { ok: false, error: "CarryBee কনফিগার করা হয়নি (Settings পেজে CarryBee তথ্য দিন)।" };
  }
  const supabase = getServerSupabase();
  const { data: order } = await supabase
    .from("orders")
    .select("*, order_items(product_name, quantity)")
    .eq("id", orderId)
    .single();
  if (!order) return { ok: false, error: "অর্ডার পাওয়া যায়নি।" };

  if (order.tracking_id && order.courier === "CarryBee") {
    return { ok: false, error: `এই অর্ডার ইতিমধ্যে CarryBee-তে পাঠানো হয়েছে (${order.tracking_id})।` };
  }

  const items = order.order_items ?? [];
  const qty = items.reduce((n: number, it: any) => n + Number(it.quantity || 0), 0) || 1;
  const address = [order.address_line, order.area, order.city, order.district]
    .filter(Boolean)
    .join(", ");
  const productDesc = items.map((it: any) => `${it.product_name} x${it.quantity}`).join(", ").slice(0, 250);

  const res = await createParcel({
    recipientName: order.customer_name,
    recipientPhone: order.customer_phone,
    recipientAddress: address,
    collectableAmount: Number(order.total), // COD
    itemQuantity: qty,
    merchantOrderId: order.order_number,
    specialInstruction: order.notes || "",
    productDescription: productDesc,
  });

  if (!res.ok) return { ok: false, error: res.error ?? "CarryBee অর্ডার ব্যর্থ।" };

  await supabase
    .from("orders")
    .update({ courier: "CarryBee", tracking_id: res.consignmentId })
    .eq("id", orderId);

  revalidatePath(`/admin/orders/${orderId}`);
  revalidatePath("/admin/orders");
  return { ok: true, consignmentId: res.consignmentId, deliveryFee: res.deliveryFee, status: res.status };
}

/** Send with edited fields from the "Send Order to Courier" modal. */
interface CarryBeeForm {
  recipientName: string;
  recipientPhone: string;
  recipientSecondaryPhone?: string;
  recipientAddress: string;
  amountToCollect: number;
  quantity: number;
  weightKg: number;
  productDescription: string;
  productType?: number;
  cityId?: number;
  zoneId?: number;
  areaId?: number;
}

export async function sendToCarryBeeCustom(orderId: string, form: CarryBeeForm) {
  await requireAdmin();
  if (!(await carrybeeConfigured())) return { ok: false, error: "CarryBee কনফিগার করা হয়নি।" };
  const supabase = getServerSupabase();
  const { data: order } = await supabase
    .from("orders")
    .select("order_number, courier, tracking_id")
    .eq("id", orderId)
    .single();
  if (!order) return { ok: false, error: "অর্ডার পাওয়া যায়নি।" };
  if (order.tracking_id && order.courier === "CarryBee") {
    return { ok: false, error: `ইতিমধ্যে পাঠানো হয়েছে (${order.tracking_id})।` };
  }

  const res = await createParcel({
    recipientName: form.recipientName,
    recipientPhone: form.recipientPhone,
    recipientSecondaryPhone: form.recipientSecondaryPhone,
    recipientAddress: form.recipientAddress,
    collectableAmount: Number(form.amountToCollect),
    itemQuantity: Math.max(1, Math.floor(Number(form.quantity) || 1)),
    itemWeightGrams: Math.max(1, Math.round((Number(form.weightKg) || 0.5) * 1000)),
    productDescription: form.productDescription,
    productType: form.productType,
    merchantOrderId: order.order_number,
    cityId: form.cityId,
    zoneId: form.zoneId,
    areaId: form.areaId,
  });
  if (!res.ok) return { ok: false, error: res.error ?? "ব্যর্থ।" };

  await supabase.from("orders").update({ courier: "CarryBee", tracking_id: res.consignmentId }).eq("id", orderId);
  revalidatePath(`/admin/orders/${orderId}`);
  revalidatePath("/admin/orders");
  return { ok: true, consignmentId: res.consignmentId, deliveryFee: res.deliveryFee, status: res.status };
}

/** Fetch the latest CarryBee status for an order's consignment. */
export async function refreshCarryBeeStatus(consignmentId: string) {
  await requireAdmin();
  const res = await getParcelStatus(consignmentId);
  return res;
}

export async function cbCities() {
  await requireAdmin();
  return listCities();
}
export async function cbZones(cityId: number) {
  await requireAdmin();
  return listZones(cityId);
}
export async function cbAreas(cityId: number, zoneId: number) {
  await requireAdmin();
  return listAreas(cityId, zoneId);
}

/** Manually (re)send an SMS for an order from the order detail view. */
export async function sendManualOrderSms(orderId: string, message: string) {
  await requireAdmin();
  if (!message.trim()) return { ok: false, error: "মেসেজ খালি।" };
  const supabase = getServerSupabase();
  const { data: order } = await supabase
    .from("orders")
    .select("customer_phone")
    .eq("id", orderId)
    .single();
  if (!order) return { ok: false, error: "অর্ডার পাওয়া যায়নি।" };
  await sendSmsAsync({ phone: order.customer_phone, message, orderId });
  revalidatePath("/admin/sms");
  return { ok: true };
}
