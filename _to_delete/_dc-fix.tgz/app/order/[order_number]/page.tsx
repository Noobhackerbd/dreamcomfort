// Thank-you / order confirmation page (server component).
import { getServerSupabase } from "@/lib/supabase/server";
import { notFound } from "next/navigation";
import { taka } from "@/lib/format";
import { PurchasePixel } from "./PurchasePixel";

export const dynamic = "force-dynamic";

async function getOrder(orderNumber: string) {
  const supabase = getServerSupabase();
  const { data: order } = await supabase
    .from("orders")
    .select("*")
    .eq("order_number", orderNumber)
    .single();
  if (!order) return null;
  const { data: items } = await supabase
    .from("order_items")
    .select("*")
    .eq("order_id", order.id);
  return { order, items: items ?? [] };
}

export default async function OrderPage({
  params,
}: {
  params: { order_number: string };
}) {
  const data = await getOrder(params.order_number);
  if (!data) notFound();
  const { order, items } = data;

  return (
    <div className="max-w-2xl mx-auto text-center">
      <div className="text-5xl mb-3">✅</div>
      <h1 className="text-2xl font-bold">ধন্যবাদ! আপনার অর্ডার পেয়েছি।</h1>
      <p className="text-gray-500 mt-2">
        আমরা শীঘ্রই আপনাকে কল করে অর্ডারটি নিশ্চিত করব।
      </p>

      <div className="mt-6 rounded-xl border bg-white p-5 text-left">
        <div className="flex justify-between border-b pb-3 mb-3">
          <span className="text-gray-500">অর্ডার নম্বর</span>
          <span className="font-bold text-brand">{order.order_number}</span>
        </div>

        <div className="space-y-2">
          {items.map((it: any) => (
            <div key={it.id} className="flex justify-between text-sm">
              <span className="truncate pr-2">
                {it.product_name} × {it.quantity}
              </span>
              <span>{taka(Number(it.line_total))}</span>
            </div>
          ))}
        </div>

        <div className="mt-3 border-t pt-3 space-y-1 text-sm">
          <div className="flex justify-between">
            <span>ডেলিভারি চার্জ</span>
            <span>{taka(Number(order.shipping_fee))}</span>
          </div>
          <div className="flex justify-between font-bold text-lg">
            <span>সর্বমোট</span>
            <span className="text-brand">{taka(Number(order.total))}</span>
          </div>
        </div>

        <div className="mt-4 border-t pt-3 text-sm text-gray-600">
          <p><b>নাম:</b> {order.customer_name}</p>
          <p><b>মোবাইল:</b> {order.customer_phone}</p>
          <p><b>ঠিকানা:</b> {order.address_line}</p>
          <p><b>পেমেন্ট:</b> ক্যাশ অন ডেলিভারি</p>
        </div>
      </div>

      <a
        href="/"
        className="inline-block mt-6 rounded-lg bg-brand text-white px-6 py-3"
      >
        আরও কেনাকাটা করুন
      </a>

      {/* Browser Purchase — deduped with the server Purchase via the stored event_id */}
      <PurchasePixel
        eventId={order.event_id ?? null}
        value={Number(order.total)}
        contentIds={items.map((it: any) => it.product_id).filter(Boolean)}
      />
    </div>
  );
}
