// lib/types.ts
export interface Product {
  id: string;
  slug: string;
  name_en: string;
  name_bn: string | null;
  description_en: string | null;
  description_bn: string | null;
  price: number;
  compare_at_price: number | null;
  sku: string | null;
  stock: number;
  category_id: string | null;
  images: string[] | null;
  is_active: boolean;
}
