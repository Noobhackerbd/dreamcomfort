// lib/config.ts — simple store settings you can tweak.
export const STORE_NAME = "Dream Comfort";

// Flat Cash-on-Delivery delivery charge in BDT.
// (Keeping checkout minimal per request. To split inside/outside Dhaka later,
//  add a field and set this per selection.)
export const DELIVERY_CHARGE = 60;

export const CURRENCY = "BDT";
