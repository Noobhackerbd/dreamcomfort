import type { Metadata } from "next";
import "./globals.css";
import { MetaPixel } from "@/components/MetaPixel";
import { Header } from "@/components/Header";
import { STORE_NAME } from "@/lib/config";

export const metadata: Metadata = {
  title: `${STORE_NAME} — আরামের সব কিছু`,
  description:
    "প্রিমিয়াম বিছানাপত্র, বালিশ ও আরামদায়ক পণ্য। সারা বাংলাদেশে ক্যাশ অন ডেলিভারি।",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="bn">
      <head>
        {/* Bangla font */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link
          href="https://fonts.googleapis.com/css2?family=Noto+Sans+Bengali:wght@400;500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="min-h-screen antialiased">
        <Header />

        <main className="mx-auto max-w-6xl px-4 py-8">{children}</main>

        <footer className="border-t bg-white mt-16">
          <div className="mx-auto max-w-6xl px-4 py-8 text-sm text-gray-500">
            © {STORE_NAME} · সারা বাংলাদেশে ক্যাশ অন ডেলিভারি
          </div>
        </footer>

        <MetaPixel />
      </body>
    </html>
  );
}
