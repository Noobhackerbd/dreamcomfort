"use client";

import { useEffect } from "react";
import { trackBrowser } from "@/components/MetaPixel";

export function PurchasePixel({
  eventId,
  value,
  contentIds,
}: {
  eventId: string | null;
  value: number;
  contentIds: string[];
}) {
  useEffect(() => {
    if (!eventId) return;
    // Same event_id as the server Purchase → Meta deduplicates the two.
    trackBrowser(
      "Purchase",
      {
        currency: "BDT",
        value,
        content_ids: contentIds,
        content_type: "product",
      },
      eventId
    );
  }, [eventId, value, contentIds]);
  return null;
}
