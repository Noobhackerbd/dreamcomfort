// app/product/[slug]/page.tsx — Product detail (server component).
import { getServerSupabase } from "@/lib/supabase/server";
import { Product } from "@/lib/types";
import { notFound } from "next/navigation";
import { BuyButtons } from "@/components/BuyButtons";
import { taka } from "@/lib/cart/store";

export const dynamic = "force-dynamic";

async function getProduct(slug: string): Promise<Product | null> {
  const supabase = getServerSupabase();
  const { data } = await supabase
    .from("products")
    .select("*")
    .eq("slug", slug)
    .eq("is_active", true)
    .single();
  return (data as Product) ?? null;
}

export default async function ProductPage({
  params,
}: {
  params: { slug: string };
}) {
  const p = await getProduct(params.slug);
  if (!p) notFound();

  const name = p.name_bn || p.name_en;
  const hasDiscount = p.compare_at_price && p.compare_at_price > p.price;
  const img = p.images?.[0];

  return (
    <div className="grid md:grid-cols-2 gap-8">
      <div className="aspect-square rounded-xl bg-gray-100 flex items-center justify-center overflow-hidden">
        {img ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={img} alt={name} className="h-full w-full object-cover" />
        ) : (
          <span className="text-gray-400">{name}</span>
        )}
      </div>

      <div>
        <h1 className="text-2xl font-bold">{name}</h1>

        <div className="mt-4 flex items-center gap-3">
          <span className="text-2xl font-bold text-brand">{taka(p.price)}</span>
          {hasDiscount && (
            <span className="text-gray-400 line-through">
              {taka(p.compare_at_price as number)}
            </span>
          )}
        </div>

        <p className="mt-4 text-gray-700 leading-relaxed">
          {p.description_bn || p.description_en || "বিস্তারিত শীঘ্রই যোগ করা হবে।"}
        </p>

        <div className="mt-6">
          <BuyButtons
            product={{ id: p.id, slug: p.slug, name, price: p.price, image: img }}
          />
          <p className="mt-3 text-xs text-gray-400">স্টক: {p.stock} টি</p>
        </div>
      </div>
    </div>
  );
}
