// app/api/capi/route.ts
// Optional generic CAPI endpoint for browser-driven events (ViewContent, AddToCart,
// InitiateCheckout). The client sends { eventName, eventId, url, customData, user? }.
// Server enriches with fbp/fbc/ip/ua from the request and forwards to Meta.
//
// IMPORTANT: For Purchase, do NOT rely on this route. Fire the server Purchase
// directly inside your checkout Server Action using the order's stored event_id,
// so it runs even if the browser tab closes. See README.

import { NextRequest, NextResponse } from "next/server";
import { sendServerEvent, MetaEventName, CustomData } from "@/lib/meta/capi";
import { getServerMatchSignals } from "@/lib/meta/fb-cookies";
import { RawUserData } from "@/lib/meta/hash";
// import { logEvent } from "@/lib/meta/log"; // wire to your Supabase events_log insert

export const runtime = "nodejs"; // crypto hashing needs the Node runtime

interface Body {
  eventName: MetaEventName;
  eventId: string;
  url: string;
  fbclid?: string;
  user?: RawUserData;
  customData?: CustomData;
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as Body;
    if (!body?.eventName || !body?.eventId || !body?.url) {
      return NextResponse.json({ ok: false, error: "missing fields" }, { status: 400 });
    }

    const signals = getServerMatchSignals(body.fbclid);

    const result = await sendServerEvent({
      eventName: body.eventName,
      eventId: body.eventId,
      eventSourceUrl: body.url,
      user: body.user ?? {},
      signals,
      customData: body.customData,
    });

    // await logEvent({ event_name: body.eventName, event_id: body.eventId,
    //   source: "server", fbtrace_id: result.fbtrace_id, payload: body });

    return NextResponse.json(result, { status: result.ok ? 200 : 502 });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message ?? "error" }, { status: 500 });
  }
}
