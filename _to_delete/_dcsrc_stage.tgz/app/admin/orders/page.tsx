import { getServerSupabase } from "@/lib/supabase/server";
import { taka } from "@/lib/cart/store";
import { StatusSelect } from "./StatusSelect";

export const dynamic = "force-dynamic";

export default async function AdminOrders() {
  const supabase = getServerSupabase();
  const { data: orders } = await supabase
    .from("orders")
    .select("id, order_number, customer_name, customer_phone, address_line, total, status, created_at, order_items(product_name, quantity)")
    .order("created_at", { ascending: false })
    .limit(200);

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">অর্ডার</h1>

      <div className="space-y-3">
        {(orders ?? []).map((o: any) => (
          <div key={o.id} className="rounded-xl border bg-white p-4">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="font-bold text-brand">{o.order_number}</p>
                <p className="text-sm mt-1">
                  {o.customer_name} · {o.customer_phone}
                </p>
                <p className="text-sm text-gray-500">{o.address_line}</p>
                <p className="text-xs text-gray-400 mt-1">
                  {(o.order_items ?? [])
                    .map((it: any) => `${it.product_name} ×${it.quantity}`)
                    .join("، ")}
                </p>
              </div>
              <div className="text-right">
                <p className="font-bold text-lg">{taka(Number(o.total))}</p>
                <div className="mt-2">
                  <StatusSelect id={o.id} value={o.status} />
                </div>
              </div>
            </div>
          </div>
        ))}
        {(!orders || orders.length === 0) && (
          <p className="text-center text-gray-400 py-10">এখনও কোনো অর্ডার নেই।</p>
        )}
      </div>
    </div>
  );
}
