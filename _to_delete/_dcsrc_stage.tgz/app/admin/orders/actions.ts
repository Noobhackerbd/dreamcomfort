"use server";

import { getServerSupabase } from "@/lib/supabase/server";
import { getSupabaseServerClient } from "@/lib/supabase/ssr-server";
import { revalidatePath } from "next/cache";

const STATUSES = [
  "pending",
  "confirmed",
  "processing",
  "shipped",
  "delivered",
  "cancelled",
  "returned",
];

async function requireAdmin() {
  const {
    data: { user },
  } = await getSupabaseServerClient().auth.getUser();
  if (!user) throw new Error("অননুমোদিত।");
  const allow = (process.env.ADMIN_ALLOWED_EMAILS || "")
    .split(",")
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);
  if (allow.length && (!user.email || !allow.includes(user.email.toLowerCase()))) {
    throw new Error("অননুমোদিত।");
  }
}

export async function updateOrderStatus(orderId: string, status: string) {
  await requireAdmin();
  if (!STATUSES.includes(status)) return { ok: false, error: "invalid status" };
  const supabase = getServerSupabase();
  const { error } = await supabase.from("orders").update({ status }).eq("id", orderId);
  if (error) return { ok: false, error: error.message };
  revalidatePath("/admin/orders");
  return { ok: true };
}
