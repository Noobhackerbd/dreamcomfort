import { getServerSupabase } from "@/lib/supabase/server";
import { notFound } from "next/navigation";
import { ProductForm } from "../ProductForm";

export const dynamic = "force-dynamic";

export default async function EditProduct({
  params,
}: {
  params: { id: string };
}) {
  const supabase = getServerSupabase();
  const { data: p } = await supabase
    .from("products")
    .select("*")
    .eq("id", params.id)
    .single();
  if (!p) notFound();

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">পণ্য এডিট</h1>
      <ProductForm
        initial={{
          id: p.id,
          name_bn: p.name_bn ?? "",
          name_en: p.name_en ?? "",
          price: Number(p.price),
          compare_at_price: p.compare_at_price ? Number(p.compare_at_price) : null,
          stock: p.stock,
          description_bn: p.description_bn ?? "",
          is_active: p.is_active,
          images: p.images ?? [],
        }}
      />
    </div>
  );
}
