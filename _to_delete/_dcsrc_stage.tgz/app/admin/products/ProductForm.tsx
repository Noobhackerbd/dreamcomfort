"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { getSupabaseBrowserClient } from "@/lib/supabase/ssr-browser";
import { saveProduct, ProductInput } from "./actions";

interface Props {
  initial?: Partial<ProductInput> & { id?: string };
}

export function ProductForm({ initial }: Props) {
  const router = useRouter();
  const [nameBn, setNameBn] = useState(initial?.name_bn ?? "");
  const [nameEn, setNameEn] = useState(initial?.name_en ?? "");
  const [price, setPrice] = useState(initial?.price?.toString() ?? "");
  const [compare, setCompare] = useState(
    initial?.compare_at_price?.toString() ?? ""
  );
  const [stock, setStock] = useState(initial?.stock?.toString() ?? "0");
  const [desc, setDesc] = useState(initial?.description_bn ?? "");
  const [active, setActive] = useState(initial?.is_active ?? true);
  const [images, setImages] = useState<string[]>(initial?.images ?? []);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function onUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files ?? []);
    if (!files.length) return;
    setUploading(true);
    setError(null);
    const supabase = getSupabaseBrowserClient();
    const uploaded: string[] = [];
    for (const file of files) {
      const ext = file.name.split(".").pop();
      const path = `${Date.now()}-${Math.floor(Math.random() * 1e6)}.${ext}`;
      const { error } = await supabase.storage
        .from("product-images")
        .upload(path, file, { cacheControl: "3600", upsert: false });
      if (error) {
        setError("ছবি আপলোড ব্যর্থ: " + error.message);
        continue;
      }
      const { data } = supabase.storage.from("product-images").getPublicUrl(path);
      uploaded.push(data.publicUrl);
    }
    setImages((prev) => [...prev, ...uploaded]);
    setUploading(false);
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!nameBn.trim() && !nameEn.trim()) return setError("পণ্যের নাম লিখুন।");
    if (!Number(price)) return setError("সঠিক দাম লিখুন।");

    setSaving(true);
    const res = await saveProduct({
      id: initial?.id,
      name_bn: nameBn,
      name_en: nameEn,
      price: Number(price),
      compare_at_price: compare ? Number(compare) : null,
      stock: Number(stock),
      description_bn: desc,
      is_active: active,
      images,
    });
    setSaving(false);
    if (!res.ok) return setError(res.error ?? "সেভ ব্যর্থ হয়েছে।");
    router.push("/admin/products");
    router.refresh();
  }

  return (
    <form onSubmit={onSubmit} className="max-w-2xl space-y-4">
      <div className="grid md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm mb-1">পণ্যের নাম (বাংলা)</label>
          <input
            value={nameBn}
            onChange={(e) => setNameBn(e.target.value)}
            placeholder="যেমন: প্রিমিয়াম কটন বেডশিট"
            className="w-full rounded-lg border px-4 py-2.5 outline-none focus:border-brand"
          />
        </div>
        <div>
          <label className="block text-sm mb-1">নাম (English — URL এর জন্য)</label>
          <input
            value={nameEn}
            onChange={(e) => setNameEn(e.target.value)}
            placeholder="e.g. Premium Cotton Bedsheet"
            className="w-full rounded-lg border px-4 py-2.5 outline-none focus:border-brand"
          />
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        <div>
          <label className="block text-sm mb-1">দাম (৳)</label>
          <input
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            inputMode="numeric"
            className="w-full rounded-lg border px-4 py-2.5 outline-none focus:border-brand"
          />
        </div>
        <div>
          <label className="block text-sm mb-1">কাটা দাম (৳, ঐচ্ছিক)</label>
          <input
            value={compare}
            onChange={(e) => setCompare(e.target.value)}
            inputMode="numeric"
            className="w-full rounded-lg border px-4 py-2.5 outline-none focus:border-brand"
          />
        </div>
        <div>
          <label className="block text-sm mb-1">স্টক</label>
          <input
            value={stock}
            onChange={(e) => setStock(e.target.value)}
            inputMode="numeric"
            className="w-full rounded-lg border px-4 py-2.5 outline-none focus:border-brand"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm mb-1">বিবরণ (বাংলা)</label>
        <textarea
          value={desc}
          onChange={(e) => setDesc(e.target.value)}
          rows={3}
          className="w-full rounded-lg border px-4 py-2.5 outline-none focus:border-brand"
        />
      </div>

      <div>
        <label className="block text-sm mb-1">ছবি</label>
        <input type="file" accept="image/*" multiple onChange={onUpload} />
        {uploading && <p className="text-sm text-gray-500 mt-1">আপলোড হচ্ছে...</p>}
        <div className="flex flex-wrap gap-2 mt-3">
          {images.map((url) => (
            <div key={url} className="relative">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={url} alt="" className="h-20 w-20 object-cover rounded-lg border" />
              <button
                type="button"
                onClick={() => setImages((p) => p.filter((u) => u !== url))}
                className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full h-5 w-5 text-xs"
              >
                ×
              </button>
            </div>
          ))}
        </div>
      </div>

      <label className="flex items-center gap-2 text-sm">
        <input
          type="checkbox"
          checked={active}
          onChange={(e) => setActive(e.target.checked)}
        />
        সক্রিয় (দোকানে দেখা যাবে)
      </label>

      {error && (
        <p className="rounded-lg bg-red-50 border border-red-200 text-red-700 px-3 py-2 text-sm">
          {error}
        </p>
      )}

      <div className="flex gap-3">
        <button
          type="submit"
          disabled={saving || uploading}
          className="rounded-lg bg-brand text-white px-6 py-2.5 font-medium hover:bg-brand-dark disabled:opacity-60"
        >
          {saving ? "সেভ হচ্ছে..." : "সেভ করুন"}
        </button>
        <a href="/admin/products" className="rounded-lg border px-6 py-2.5">
          বাতিল
        </a>
      </div>
    </form>
  );
}
