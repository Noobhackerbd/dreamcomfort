"use server";

import { getServerSupabase } from "@/lib/supabase/server";
import { getSupabaseServerClient } from "@/lib/supabase/ssr-server";
import { revalidatePath } from "next/cache";

async function requireAdmin() {
  const supabase = getSupabaseServerClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error("অননুমোদিত।");
  const allow = (process.env.ADMIN_ALLOWED_EMAILS || "")
    .split(",")
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);
  if (allow.length && (!user.email || !allow.includes(user.email.toLowerCase()))) {
    throw new Error("অননুমোদিত।");
  }
}

function slugify(input: string): string {
  const base = input
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9ঀ-৿]+/g, "-")
    .replace(/^-+|-+$/g, "");
  return base || "product-" + Math.floor(Math.random() * 100000);
}

export interface ProductInput {
  id?: string;
  name_bn: string;
  name_en: string;
  price: number;
  compare_at_price?: number | null;
  stock: number;
  description_bn?: string;
  is_active: boolean;
  images: string[];
}

export async function saveProduct(input: ProductInput) {
  await requireAdmin();
  const supabase = getServerSupabase();

  const row = {
    name_bn: input.name_bn?.trim() || null,
    name_en: input.name_en?.trim() || input.name_bn?.trim() || "পণ্য",
    price: Number(input.price) || 0,
    compare_at_price: input.compare_at_price ? Number(input.compare_at_price) : null,
    stock: Math.max(0, Math.floor(Number(input.stock) || 0)),
    description_bn: input.description_bn?.trim() || null,
    is_active: !!input.is_active,
    images: input.images ?? [],
  };

  if (input.id) {
    const { error } = await supabase.from("products").update(row).eq("id", input.id);
    if (error) return { ok: false, error: error.message };
  } else {
    const slug = slugify(input.name_en || input.name_bn || "");
    const { error } = await supabase.from("products").insert({ ...row, slug });
    if (error) return { ok: false, error: error.message };
  }

  revalidatePath("/admin/products");
  revalidatePath("/");
  return { ok: true };
}

export async function deleteProduct(id: string) {
  await requireAdmin();
  const supabase = getServerSupabase();
  const { error } = await supabase.from("products").delete().eq("id", id);
  if (error) return { ok: false, error: error.message };
  revalidatePath("/admin/products");
  revalidatePath("/");
  return { ok: true };
}
