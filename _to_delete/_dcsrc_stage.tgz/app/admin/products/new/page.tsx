import { ProductForm } from "../ProductForm";

export const dynamic = "force-dynamic";

export default function NewProduct() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">নতুন পণ্য</h1>
      <ProductForm />
    </div>
  );
}
