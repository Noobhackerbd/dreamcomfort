"use server";

import { getServerSupabase } from "@/lib/supabase/server";
import { getServerMatchSignals } from "@/lib/meta/fb-cookies";
import { newEventId } from "@/lib/meta/event-id";
import { sendServerEvent } from "@/lib/meta/capi";
import { DELIVERY_CHARGE } from "@/lib/config";

export interface PlaceOrderInput {
  name: string;
  phone: string;
  address: string;
  items: { id: string; qty: number }[];
  fbclid?: string;
}

export interface PlaceOrderResult {
  ok: boolean;
  orderNumber?: string;
  error?: string;
}

/** Normalize a BD phone to 8801XXXXXXXXX for storage/matching. */
function normalizePhone(raw: string): string {
  let d = raw.replace(/\D/g, "");
  if (d.startsWith("00")) d = d.slice(2);
  if (d.startsWith("0")) d = "88" + d;
  else if (d.startsWith("1")) d = "880" + d;
  else if (!d.startsWith("880")) d = "880" + d;
  return d;
}

export async function placeOrder(input: PlaceOrderInput): Promise<PlaceOrderResult> {
  try {
    const name = input.name?.trim();
    const address = input.address?.trim();
    const phoneDigits = (input.phone || "").replace(/\D/g, "");

    if (!name) return { ok: false, error: "নাম লিখুন।" };
    if (!/^01\d{9}$/.test(phoneDigits))
      return { ok: false, error: "সঠিক মোবাইল নম্বর লিখুন (০১XXXXXXXXX)।" };
    if (!address || address.length < 5)
      return { ok: false, error: "সম্পূর্ণ ঠিকানা লিখুন।" };
    if (!input.items?.length) return { ok: false, error: "কার্ট খালি।" };

    const supabase = getServerSupabase();

    // Re-fetch prices from DB — never trust prices sent from the browser.
    const ids = input.items.map((i) => i.id);
    const { data: products, error: pErr } = await supabase
      .from("products")
      .select("id, name_bn, name_en, price")
      .in("id", ids);
    if (pErr) return { ok: false, error: pErr.message };
    if (!products?.length) return { ok: false, error: "পণ্য খুঁজে পাওয়া যায়নি।" };

    const priceMap = new Map(products.map((p: any) => [p.id, p]));
    let subtotal = 0;
    const lineItems = input.items
      .map((i) => {
        const p: any = priceMap.get(i.id);
        if (!p) return null;
        const qty = Math.max(1, Math.floor(i.qty));
        const line = Number(p.price) * qty;
        subtotal += line;
        return {
          product_id: p.id,
          product_name: p.name_bn || p.name_en,
          unit_price: Number(p.price),
          quantity: qty,
          line_total: line,
        };
      })
      .filter(Boolean) as any[];

    const total = subtotal + DELIVERY_CHARGE;

    // Meta matching signals + shared event_id (used later for CAPI Purchase dedup).
    const eventId = newEventId();
    const signals = getServerMatchSignals(input.fbclid);

    // Create the order.
    const { data: order, error: oErr } = await supabase
      .from("orders")
      .insert({
        status: "pending",
        customer_name: name,
        customer_phone: normalizePhone(input.phone),
        address_line: address,
        payment_method: "cod",
        subtotal,
        shipping_fee: DELIVERY_CHARGE,
        discount: 0,
        total,
        event_id: eventId,
        fbp: signals.fbp ?? null,
        fbc: signals.fbc ?? null,
        client_ip: signals.client_ip_address ?? null,
        client_user_agent: signals.client_user_agent ?? null,
      })
      .select("id, order_number, total")
      .single();

    if (oErr || !order) return { ok: false, error: oErr?.message ?? "অর্ডার তৈরি ব্যর্থ।" };

    // Insert items.
    const { error: iErr } = await supabase
      .from("order_items")
      .insert(lineItems.map((li) => ({ ...li, order_id: order.id })));
    if (iErr) return { ok: false, error: iErr.message };

    // Fire server-side Purchase ONLY if Meta is configured (safe no-op otherwise).
    if (process.env.META_CAPI_ACCESS_TOKEN && process.env.NEXT_PUBLIC_META_PIXEL_ID) {
      try {
        const res = await sendServerEvent({
          eventName: "Purchase",
          eventId,
          eventSourceUrl: `${process.env.NEXT_PUBLIC_SITE_URL}/order/${order.order_number}`,
          user: { phone: input.phone, externalId: input.phone },
          signals,
          customData: {
            currency: "BDT",
            value: Number(order.total),
            num_items: lineItems.reduce((n, li) => n + li.quantity, 0),
            content_ids: lineItems.map((li) => li.product_id),
            content_type: "product",
            contents: lineItems.map((li) => ({
              id: li.product_id,
              quantity: li.quantity,
              item_price: li.unit_price,
            })),
          },
        });
        await supabase.from("events_log").insert({
          event_name: "Purchase",
          event_id: eventId,
          source: "server",
          fbtrace_id: res.fbtrace_id ?? null,
          payload: { order_number: order.order_number },
        });
      } catch {
        // never fail the order because tracking failed
      }
    }

    return { ok: true, orderNumber: order.order_number };
  } catch (e: any) {
    return { ok: false, error: e?.message ?? "কিছু একটা সমস্যা হয়েছে।" };
  }
}
