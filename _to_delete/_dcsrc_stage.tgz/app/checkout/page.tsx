"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useCart, taka } from "@/lib/cart/store";
import { DELIVERY_CHARGE } from "@/lib/config";
import { placeOrder } from "./actions";
import { newBrowserEventId } from "@/lib/meta/event-id";
import { trackBrowser } from "@/components/MetaPixel";

export default function CheckoutPage() {
  const router = useRouter();
  const { items, subtotal, clear } = useCart();
  const [mounted, setMounted] = useState(false);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => setMounted(true), []);

  // Fire InitiateCheckout (browser) once the cart is shown.
  useEffect(() => {
    if (mounted && items.length > 0) {
      trackBrowser(
        "InitiateCheckout",
        { currency: "BDT", value: subtotal() + DELIVERY_CHARGE, num_items: items.length },
        newBrowserEventId()
      );
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mounted]);

  if (!mounted) return null;

  if (items.length === 0) {
    return (
      <div className="text-center py-20">
        <p className="text-lg text-gray-500">আপনার কার্ট খালি।</p>
        <a href="/" className="inline-block mt-5 rounded-lg bg-brand text-white px-6 py-3">
          কেনাকাটা শুরু করুন
        </a>
      </div>
    );
  }

  const sub = subtotal();
  const total = sub + DELIVERY_CHARGE;

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    // basic client-side check with Bangla messages
    const phoneDigits = phone.replace(/\D/g, "");
    if (!name.trim()) return setError("নাম লিখুন।");
    if (!/^01\d{9}$/.test(phoneDigits)) return setError("সঠিক মোবাইল নম্বর লিখুন (০১XXXXXXXXX)।");
    if (address.trim().length < 5) return setError("সম্পূর্ণ ঠিকানা লিখুন।");

    setSubmitting(true);
    const res = await placeOrder({
      name,
      phone,
      address,
      items: items.map((i) => ({ id: i.id, qty: i.qty })),
    });
    setSubmitting(false);

    if (!res.ok) {
      setError(res.error ?? "অর্ডার ব্যর্থ হয়েছে।");
      return;
    }
    clear();
    router.push(`/order/${res.orderNumber}`);
  }

  return (
    <div className="max-w-2xl">
      <h1 className="text-2xl font-bold mb-6">চেকআউট</h1>

      <form onSubmit={onSubmit} className="space-y-4">
        <div>
          <label className="block text-sm mb-1">আপনার নাম</label>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="আপনার নাম লিখুন"
            className="w-full rounded-lg border px-4 py-3 outline-none focus:border-brand"
          />
        </div>

        <div>
          <label className="block text-sm mb-1">মোবাইল নম্বর</label>
          <input
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            inputMode="numeric"
            placeholder="০১XXXXXXXXX"
            className="w-full rounded-lg border px-4 py-3 outline-none focus:border-brand"
          />
        </div>

        <div>
          <label className="block text-sm mb-1">সম্পূর্ণ ঠিকানা</label>
          <textarea
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            rows={3}
            placeholder="বাসা/হোল্ডিং, রোড, এলাকা, থানা, জেলা"
            className="w-full rounded-lg border px-4 py-3 outline-none focus:border-brand"
          />
        </div>

        {/* Order summary */}
        <div className="rounded-xl border bg-white p-4 space-y-2">
          {items.map((i) => (
            <div key={i.id} className="flex justify-between text-sm">
              <span className="truncate pr-2">
                {i.name} × {i.qty}
              </span>
              <span>{taka(i.price * i.qty)}</span>
            </div>
          ))}
          <div className="flex justify-between text-sm border-t pt-2">
            <span>ডেলিভারি চার্জ</span>
            <span>{taka(DELIVERY_CHARGE)}</span>
          </div>
          <div className="flex justify-between font-bold text-lg border-t pt-2">
            <span>সর্বমোট</span>
            <span className="text-brand">{taka(total)}</span>
          </div>
        </div>

        {error && (
          <p className="rounded-lg bg-red-50 border border-red-200 text-red-700 px-4 py-2 text-sm">
            {error}
          </p>
        )}

        <button
          type="submit"
          disabled={submitting}
          className="w-full rounded-lg bg-brand text-white px-6 py-3 font-medium hover:bg-brand-dark disabled:opacity-60"
        >
          {submitting ? "অর্ডার হচ্ছে..." : "অর্ডার নিশ্চিত করুন (ক্যাশ অন ডেলিভারি)"}
        </button>
        <p className="text-center text-xs text-gray-400">
          অর্ডার করার পর আমরা কল করে নিশ্চিত করব।
        </p>
      </form>
    </div>
  );
}
