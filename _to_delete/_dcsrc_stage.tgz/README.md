# Dream Comfort BD — Runnable Starter

A real, working Next.js 14 storefront wired to **your** Supabase database. Run it and you'll
see your seed products on the homepage. This is the foundation — checkout, admin panel, and full
Meta tracking get built on top of it using `MASTER-PROMPT.md`.

---

## What you need installed (one time)

1. **Node.js 18+** — download the "LTS" version from https://nodejs.org and install it.
   To check it worked, open a terminal and run: `node -v` (should print a version like `v20.x`).
2. A code editor — **VS Code** (https://code.visualstudio.com) is free and recommended.

---

## Step 1 — Get your Supabase keys

In the Supabase dashboard for your project:

1. Click the **gear icon (Project Settings)** in the bottom-left.
2. Click **API** (under "Configuration").
3. You need three values from this page:
   - **Project URL** → e.g. `https://abcdxyz.supabase.co`
   - **Project API keys → `anon` `public`** → a long string starting with `eyJ...`
   - **Project API keys → `service_role` `secret`** → another long `eyJ...` string
     (click "Reveal"). **Keep this one secret — never share it or put it in the browser.**

---

## Step 2 — Configure the project

1. Unzip this folder somewhere easy, e.g. `Desktop/dc-app`.
2. Open the folder in VS Code (File → Open Folder).
3. Find the file `.env.example`, **make a copy of it named `.env.local`**, and open it.
4. Paste your three Supabase values in:

   ```
   NEXT_PUBLIC_SUPABASE_URL=https://abcdxyz.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...your anon key...
   SUPABASE_SERVICE_ROLE_KEY=eyJ...your service_role key...
   ```

   Leave the Meta values blank for now — we add those later.

---

## Step 3 — Run it

Open the terminal in VS Code (**Terminal → New Terminal**) and run these two commands:

```bash
npm install
npm run dev
```

Then open **http://localhost:3000** in your browser. You should see the Dream Comfort BD
landing page with your 6 seed products. 🎉

If you see a red "Could not load products" box, double-check the three keys in `.env.local`
(then stop the server with `Ctrl+C` and run `npm run dev` again — env changes need a restart).

---

## What's included

```
app/
  layout.tsx              header/footer + Meta Pixel loader
  page.tsx                landing page (reads your products from Supabase)
  product/[slug]/page.tsx product detail page
  api/capi/route.ts       server-side Meta Conversions API endpoint
components/MetaPixel.tsx   browser Pixel + trackBrowser() helper
lib/supabase/             server + browser Supabase clients
lib/meta/                 hashing, CAPI sender, event-id, cookies + README
supabase-schema.sql       (same schema you already ran — kept for reference)
MASTER-PROMPT.md          the full build spec for the rest of the site
```

---

## What's next (build on this base)

Do these in order. For each, open `MASTER-PROMPT.md`, copy the relevant section, and paste it
into your AI coding tool (Cursor, or Claude) with the instruction "add this to my existing project":

1. **Cart + COD checkout** (Master Prompt §4) — the "Order Now" button, checkout form, order creation.
2. **Admin panel + login** (§5) — add/manage products with image upload, manage orders.
3. **SMS notifications** (§6).
4. **Full Meta Pixel + CAPI events** (§7) — the code in `lib/meta/` is ready; wire the events using
   `lib/meta/README.md`. Verify pixel health in Events Manager → Test Events.
5. **Deploy to Vercel** — push to GitHub, import at vercel.com, paste the same env vars.

Tip: build and test ONE piece at a time. After each addition, run `npm run dev` and check it works
before moving on.
