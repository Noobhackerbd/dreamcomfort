import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // calm comfort-brand palette — tweak to your logo
        brand: {
          DEFAULT: "#0d9488", // teal-600
          dark: "#0f766e",
          light: "#5eead4",
        },
      },
    },
  },
  plugins: [],
};
export default config;
