"use client";

import { useEffect, useState } from "react";
import { useCart } from "@/lib/cart/store";
import { STORE_NAME } from "@/lib/config";

export function Header() {
  const count = useCart((s) => s.count());
  // avoid hydration mismatch: only show count after mount
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  return (
    <header className="sticky top-0 z-40 bg-white border-b">
      <div className="mx-auto max-w-6xl px-4 h-16 flex items-center justify-between">
        <a href="/" className="text-xl font-bold text-brand">
          {STORE_NAME}
        </a>
        <nav className="flex items-center gap-5 text-sm">
          <a href="/" className="hover:text-brand">হোম</a>
          <a href="/track-order" className="hover:text-brand">অর্ডার ট্র্যাক</a>
          <a href="/admin" className="hover:text-brand">অ্যাডমিন</a>
          <a
            href="/cart"
            className="relative rounded-full bg-brand text-white px-4 py-1.5"
          >
            কার্ট
            {mounted && count > 0 && (
              <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                {count}
              </span>
            )}
          </a>
        </nav>
      </div>
    </header>
  );
}
