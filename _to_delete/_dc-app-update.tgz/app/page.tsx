// app/page.tsx — storefront home (server component).
import { getServerSupabase } from "@/lib/supabase/server";
import { Product, Category } from "@/lib/types";
import { ProductCard } from "@/components/ProductCard";
import { STORE } from "@/lib/config";

export const dynamic = "force-dynamic";

async function getData() {
  const supabase = getServerSupabase();
  const [{ data: products }, { data: categories }] = await Promise.all([
    supabase
      .from("products")
      .select("*")
      .eq("is_active", true)
      .order("created_at", { ascending: false })
      .limit(12),
    supabase.from("categories").select("*").order("sort_order", { ascending: true }),
  ]);
  return {
    products: (products as Product[]) ?? [],
    categories: (categories as Category[]) ?? [],
  };
}

const REVIEWS = [
  { name: "Sadia R.", text: "কাপড়ের মান খুব ভালো, দ্রুত ডেলিভারি পেয়েছি।", stars: 5 },
  { name: "Tanvir H.", text: "ক্যাশ অন ডেলিভারিতে অর্ডার করেছি, প্রোডাক্ট দারুণ।", stars: 5 },
  { name: "Nusrat J.", text: "বালিশটা খুবই আরামদায়ক। আবার কিনব।", stars: 4 },
];

export default async function HomePage() {
  const { products, categories } = await getData();

  return (
    <div>
      {/* Hero */}
      <section className="rounded-2xl bg-gradient-to-br from-brand to-brand-dark text-white p-8 md:p-12 mb-10">
        <h1 className="text-3xl md:text-4xl font-bold">{STORE.name}</h1>
        <p className="mt-3 text-white/90 text-lg max-w-xl">
          {STORE.tagline} — প্রিমিয়াম বিছানাপত্র, বালিশ ও আরামদায়ক পণ্য। সারা বাংলাদেশে ক্যাশ অন ডেলিভারি।
        </p>
        <a
          href="/products"
          className="inline-block mt-6 rounded-lg bg-white text-brand px-6 py-3 font-medium hover:bg-white/90"
        >
          এখনই কেনাকাটা করুন
        </a>
      </section>

      {/* Trust badges */}
      <section className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-10 text-center text-sm">
        {[
          ["🚚", "সারা দেশে ডেলিভারি"],
          ["💵", "ক্যাশ অন ডেলিভারি"],
          ["↩️", "সহজ রিটার্ন"],
          ["📞", "দ্রুত সাপোর্ট"],
        ].map(([icon, label]) => (
          <div key={label} className="rounded-xl border bg-white py-4">
            <div className="text-2xl">{icon}</div>
            <div className="mt-1 text-gray-600">{label}</div>
          </div>
        ))}
      </section>

      {/* Categories */}
      {categories.length > 0 && (
        <section className="mb-10">
          <h2 className="text-lg font-bold mb-4">ক্যাটাগরি</h2>
          <div className="flex flex-wrap gap-3">
            {categories.map((c) => (
              <a
                key={c.id}
                href={`/products?category=${c.slug}`}
                className="rounded-full border bg-white px-5 py-2 text-sm hover:border-brand hover:text-brand"
              >
                {c.name_bn || c.name_en}
              </a>
            ))}
          </div>
        </section>
      )}

      {/* Featured products */}
      <section className="mb-12">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold">জনপ্রিয় পণ্য</h2>
          <a href="/products" className="text-sm text-brand hover:underline">
            সব পণ্য →
          </a>
        </div>
        {products.length === 0 ? (
          <div className="text-center py-20 text-gray-400">
            এখনও কোনো পণ্য যোগ করা হয়নি।
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {products.map((p) => (
              <ProductCard key={p.id} p={p} />
            ))}
          </div>
        )}
      </section>

      {/* Reviews */}
      <section className="mb-6">
        <h2 className="text-lg font-bold mb-4">গ্রাহকদের মতামত</h2>
        <div className="grid gap-4 md:grid-cols-3">
          {REVIEWS.map((r) => (
            <div key={r.name} className="rounded-xl border bg-white p-5">
              <div className="text-amber-400">{"★".repeat(r.stars)}{"☆".repeat(5 - r.stars)}</div>
              <p className="mt-2 text-gray-700 text-sm">{r.text}</p>
              <p className="mt-3 text-xs text-gray-400">— {r.name}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
