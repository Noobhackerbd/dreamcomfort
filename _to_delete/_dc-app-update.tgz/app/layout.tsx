import type { Metadata } from "next";
import "./globals.css";
import { MetaPixel } from "@/components/MetaPixel";
import { Header } from "@/components/Header";
import { STORE, STORE_NAME } from "@/lib/config";

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || "https://dreamcomfortbd.com";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: `${STORE_NAME} — আরামের সব কিছু`,
    template: `%s — ${STORE_NAME}`,
  },
  description:
    "প্রিমিয়াম বিছানাপত্র, বালিশ ও আরামদায়ক পণ্য। সারা বাংলাদেশে ক্যাশ অন ডেলিভারি।",
  openGraph: {
    siteName: STORE_NAME,
    locale: "bn_BD",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="bn">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link
          href="https://fonts.googleapis.com/css2?family=Noto+Sans+Bengali:wght@400;500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="min-h-screen antialiased flex flex-col">
        <Header />

        <main className="mx-auto max-w-6xl px-4 py-8 w-full flex-1">{children}</main>

        <footer className="border-t bg-white mt-16">
          <div className="mx-auto max-w-6xl px-4 py-10 grid gap-8 md:grid-cols-4 text-sm">
            <div>
              <p className="text-lg font-bold text-brand">{STORE_NAME}</p>
              <p className="mt-2 text-gray-500">{STORE.tagline}</p>
              <p className="mt-2 text-gray-500">সারা বাংলাদেশে ক্যাশ অন ডেলিভারি।</p>
            </div>
            <div>
              <p className="font-semibold mb-2">শপ</p>
              <ul className="space-y-1 text-gray-500">
                <li><a href="/products" className="hover:text-brand">সব পণ্য</a></li>
                <li><a href="/track-order" className="hover:text-brand">অর্ডার ট্র্যাক</a></li>
                <li><a href="/cart" className="hover:text-brand">কার্ট</a></li>
              </ul>
            </div>
            <div>
              <p className="font-semibold mb-2">সহায়তা</p>
              <ul className="space-y-1 text-gray-500">
                <li><a href="/about" className="hover:text-brand">আমাদের সম্পর্কে</a></li>
                <li><a href="/contact" className="hover:text-brand">যোগাযোগ</a></li>
                <li><a href="/return-policy" className="hover:text-brand">রিটার্ন পলিসি</a></li>
                <li><a href="/privacy" className="hover:text-brand">প্রাইভেসি</a></li>
                <li><a href="/terms" className="hover:text-brand">শর্তাবলী</a></li>
              </ul>
            </div>
            <div>
              <p className="font-semibold mb-2">যোগাযোগ</p>
              <ul className="space-y-1 text-gray-500">
                <li>📞 <a href={`tel:${STORE.phone}`} className="hover:text-brand">{STORE.phone}</a></li>
                <li>✉️ <a href={`mailto:${STORE.email}`} className="hover:text-brand">{STORE.email}</a></li>
                <li>📍 {STORE.address}</li>
                <li><a href={STORE.facebook} className="hover:text-brand" rel="noopener" target="_blank">Facebook</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t">
            <div className="mx-auto max-w-6xl px-4 py-4 text-xs text-gray-400">
              © {STORE_NAME} · সকল অধিকার সংরক্ষিত
            </div>
          </div>
        </footer>

        <MetaPixel />
      </body>
    </html>
  );
}
