// lib/config.ts — store settings. Values here are sensible defaults; the admin
// Settings page can override shipping fees + store info at runtime (see lib/settings.ts).

export const STORE = {
  name: "Dream Comfort",
  nameBn: "ড্রিম কমফোর্ট",
  tagline: "আরামের সব কিছু",
  phone: "01700000000",
  whatsapp: "01700000000",
  email: "support@dreamcomfortbd.com",
  facebook: "https://facebook.com/dreamcomfortbd",
  instagram: "https://instagram.com/dreamcomfortbd",
  address: "ঢাকা, বাংলাদেশ",
};

// Back-compat single name export (used widely across the app).
export const STORE_NAME = STORE.name;

// Cash-on-Delivery shipping fees (BDT). Admin Settings can override these.
export const SHIPPING = {
  insideDhaka: 60,
  outsideDhaka: 120,
};

// Back-compat flat charge (defaults to inside-Dhaka).
export const DELIVERY_CHARGE = SHIPPING.insideDhaka;

export const CURRENCY = "BDT";

export type DeliveryArea = "inside" | "outside";

/** Static shipping fee for an area. Runtime override happens server-side in checkout. */
export function shippingFeeFor(area: DeliveryArea): number {
  return area === "outside" ? SHIPPING.outsideDhaka : SHIPPING.insideDhaka;
}
