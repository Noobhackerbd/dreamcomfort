// lib/sound.ts — tiny Web Audio sound effects (no asset files).
// Soft, gentle tones that match the calm brand vibe. Respects a mute flag.
"use client";

let ctx: AudioContext | null = null;
let muted = false;

function getCtx(): AudioContext | null {
  if (typeof window === "undefined") return null;
  try {
    if (!ctx) {
      const AC = window.AudioContext || (window as any).webkitAudioContext;
      if (!AC) return null;
      ctx = new AC();
    }
    if (ctx.state === "suspended") ctx.resume();
    return ctx;
  } catch {
    return null;
  }
}

export function setMuted(v: boolean) {
  muted = v;
  if (typeof window !== "undefined") {
    try {
      window.localStorage.setItem("dc-muted", v ? "1" : "0");
    } catch {}
  }
}

export function isMuted(): boolean {
  if (typeof window !== "undefined") {
    try {
      return window.localStorage.getItem("dc-muted") === "1";
    } catch {}
  }
  return muted;
}

/** Play one soft sine "note". */
function note(freq: number, start: number, dur: number, gain = 0.06, type: OscillatorType = "sine") {
  const c = getCtx();
  if (!c || isMuted()) return;
  const osc = c.createOscillator();
  const g = c.createGain();
  osc.type = type;
  osc.frequency.value = freq;
  const t0 = c.currentTime + start;
  g.gain.setValueAtTime(0, t0);
  g.gain.linearRampToValueAtTime(gain, t0 + 0.015);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  osc.connect(g);
  g.connect(c.destination);
  osc.start(t0);
  osc.stop(t0 + dur + 0.02);
}

/** Soft tick — selection / toggle. */
export function playTick() {
  note(880, 0, 0.12, 0.04, "sine");
}

/** Gentle pop — add to cart / quantity. */
export function playPop() {
  note(523.25, 0, 0.1, 0.05);
  note(783.99, 0.04, 0.12, 0.045);
}

/** Warm confirm — button press. */
export function playConfirm() {
  note(587.33, 0, 0.14, 0.05);
  note(880, 0.07, 0.16, 0.05);
}

/** Happy success chime — order placed (C-E-G-C arpeggio). */
export function playSuccess() {
  [523.25, 659.25, 783.99, 1046.5].forEach((f, i) => note(f, i * 0.12, 0.5, 0.06));
}

/** Gentle "oops" — two descending low tones for a validation error. */
export function playError() {
  note(311.13, 0, 0.18, 0.06, "triangle");
  note(233.08, 0.13, 0.26, 0.06, "triangle");
}
