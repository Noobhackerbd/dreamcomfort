"use client";

import { useEffect, useState } from "react";
import { playConfirm } from "@/lib/sound";

/**
 * Mobile sticky order button. It actually SUBMITS the order form (not just scroll):
 * clicking it runs the same validation + placeOrder as the form's own button.
 * It also hides itself while the form is on screen, so the form's own order
 * button is never covered.
 */
export function StickyOrderButton({ label }: { label: string }) {
  const [formVisible, setFormVisible] = useState(false);

  useEffect(() => {
    const form = document.getElementById("order-form");
    if (!form) return;
    const io = new IntersectionObserver(
      ([entry]) => setFormVisible(entry.isIntersecting),
      { threshold: 0.4 }
    );
    io.observe(form);
    return () => io.disconnect();
  }, []);

  // While the form (with its own button) is visible, hide the sticky bar.
  if (formVisible) return null;

  function onClick() {
    const form = document.getElementById("order-form") as HTMLFormElement | null;
    if (!form) return;
    playConfirm();
    // Trigger the form's onSubmit (validation → placeOrder → redirect / show error).
    form.requestSubmit();
    form.scrollIntoView({ behavior: "smooth", block: "center" });
  }

  return (
    <button
      type="button"
      onClick={onClick}
      className="lg:hidden fixed bottom-4 inset-x-3 z-50 dc-pulse flex items-center justify-center gap-2 rounded-2xl bg-accent-dark text-white px-5 py-4 text-base font-bold shadow-[0_10px_30px_-4px_rgba(231,123,166,0.85)] ring-2 ring-white"
    >
      <span className="text-xl">🛒</span>
      {label}
    </button>
  );
}
